<?php
/**
 * 모듈 문구 언어 (한국어·영어). 한국어 원문을 열쇠로 appapiText::t('…') 에 넣고, 값 자리는 {0}, {1} …
 * 영어 문구는 lang/text.en.php (한국어 원문 → 영어).
 * - 관리 화면·업데이트: 관리 화면 언어 (한국어가 아니면 영어)
 * - 앱에 보내는 문구(오류 등): 앱이 보낸 언어(X-App-Lang: ko|en), 없으면(예전 앱) 사이트 언어
 * 엔진이 만든 문구와 사이트 내용(게시판 이름·글)은 바꾸지 않는다.
 * 앱(iOS·Android)의 tr() 과 같은 방식이다.
 */
class appapiText
{
	private static $code = null;
	private static $english = null;

	public static function code()
	{
		if (self::$code === null)
		{
			$requested = isset($_SERVER['HTTP_X_APP_LANG']) ? strtolower(substr((string)$_SERVER['HTTP_X_APP_LANG'], 0, 2)) : '';
			if (defined('APPAPI_VERSION') && ($requested === 'ko' || $requested === 'en'))
			{
				self::$code = $requested;
			}
			else
			{
				$site = class_exists('Context') ? (string)Context::getLangType() : 'ko';
				self::$code = ($site === 'ko' || $site === '') ? 'ko' : 'en';
			}
		}
		return self::$code;
	}

	public static function t($ko)
	{
		$text = $ko;
		if (self::code() === 'en')
		{
			if (self::$english === null)
			{
				$file = dirname(__DIR__) . '/lang/text.en.php';
				self::$english = is_file($file) ? (array)include $file : array();
			}
			if (isset(self::$english[$ko]))
			{
				$text = self::$english[$ko];
			}
		}
		$args = func_get_args();
		for ($i = 1; $i < count($args); $i++)
		{
			$text = str_replace('{' . ($i - 1) . '}', (string)$args[$i], $text);
		}
		return $text;
	}
}

/** 관리 화면 템플릿용: {$tr->t('…')} */
class appapiTextView
{
	public function t($ko)
	{
		return call_user_func_array(array('appapiText', 't'), func_get_args());
	}
}
