<?php
/**
 * 앱 연동 설정 저장
 */
class appapiAdminController extends appapi
{
	function init()
	{
	}

	function procAppapiAdminInsertConfig()
	{
		$vars = Context::getRequestVars();
		$config = new stdClass;
		$config->site_name = mb_substr(trim(strip_tags((string)$vars->site_name)), 0, 100);
		$config->theme_color = preg_match('/^#[0-9a-fA-F]{6}$/', trim((string)$vars->theme_color)) ? trim($vars->theme_color) : '';
		$config->logo_url = $this->cleanUrl($vars->logo_url);
		$config->icon_url = $this->cleanUrl($vars->icon_url);
		$config->voter_name = ((string)$vars->voter_name === 'nick_name') ? 'nick_name' : 'nick_name_user_name';
		$config->author_name = ((string)$vars->author_name === 'nick_name_user_name') ? 'nick_name_user_name' : 'nick_name';

		$output = getController('module')->insertModuleConfig('appapi', $config);
		if (!$output->toBool())
		{
			return $output;
		}
		$this->setMessage('success_updated');
		$this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispAppapiAdminConfig'));
	}

	/** 관리자 화면의 [업데이트]: 새 버전을 받아 서명을 확인하고 덮어쓴다 */
	function procAppapiAdminUpdate()
	{
		$logged_info = Context::get('logged_info');
		if (!$logged_info || $logged_info->is_admin !== 'Y')
		{
			return new BaseObject(-1, 'msg_not_permitted');
		}
		require_once __DIR__ . '/appapi.updater.php';
		$_SESSION['appapi_update_result'] = appapiUpdater::update();
		$this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispAppapiAdminConfig'));
	}

	/** http(s) 주소 또는 사이트 안 경로(/files/...)만 받는다 */
	private function cleanUrl($url)
	{
		$url = trim((string)$url);
		return (preg_match('#^https?://[^\s"<>]+$#i', $url) || preg_match('#^/[^\s"<>]*$#', $url)) ? $url : '';
	}
}
