<?php
/**
 * 앱 연동(게시판모아 BoardMoa) 모듈.
 *
 * 실제 API 는 api.php (modules/appapi/api.php?r=...) 이고, 이 모듈은 설치·관리자 설정 화면을 맡는다.
 * 앱 전용 토큰 테이블(<prefix>appapi_tokens)은 첫 로그인 때 만들어진다.
 */
class appapi extends ModuleObject
{
	function moduleInstall()
	{
		return new BaseObject();
	}

	function checkUpdate()
	{
		return false;
	}

	function moduleUpdate()
	{
		return new BaseObject(0, 'success_updated');
	}

	function recompileCache()
	{
	}
}
