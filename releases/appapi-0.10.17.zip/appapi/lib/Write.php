<?php
namespace AppApi;

/**
 * 글·댓글 쓰기와 삭제.
 *
 * 웹과 같은 게시판 액션(procBoardInsertDocument 등)을 실행하므로 쓰기 권한, 본인 확인, 스팸 방지,
 * 포인트, 알림 같은 규칙을 엔진이 그대로 적용한다. 앱은 일반 글자로 보내고 여기서 HTML 로 바꾼다
 * (새 글은 content_format=html 이면 앱 편집기의 HTML 을 그대로 받고, 거르기는 엔진이 한다).
 */
class Write
{
	public static function insertDocument()
	{
		$mid = self::writableBoard('write_document');
		$title = trim((string)Core::param('title'));
		// content_format=html: 앱의 꾸밈 편집기(굵게·색·크기 등)가 만든 HTML. 글 고치기(document.update)처럼 그대로 넘기고
		// 정리(위험한 태그·속성 거르기)는 엔진이 한다. 없으면(예전 앱) 일반 글자로 받아 HTML 로 바꾼다.
		$content = Core::param('content_format') === 'html' ? self::editorHtml(Core::param('content')) : self::textToHtml(Core::param('content'));
		$photos = self::uploadedPhotos();
		if ($title === '' || ($content === '' && !$photos))
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('제목과 내용을 입력해 주세요.'));
		}
		// 비회원 글: 웹 글쓰기 화면처럼 이름·비밀번호를 받는다 (모듈 0.10.16~, board.guest_fields)
		$guest = self::guestFields();
		// 앱 요청은 쿠키가 없어 CSRF 와 무관하다: 비회원 글도 엔진의 같은 사이트 요청 검사를 통과시킨다 (가입·투표와 같음)
		Board::$allowGuestWrite = $guest !== null;
		try
		{
			return self::insertDocumentAs($mid, $title, $content, $photos, $guest);
		}
		finally
		{
			Board::$allowGuestWrite = false;
		}
	}

	private static function insertDocumentAs($mid, $title, $content, array $photos, $guest)
	{
		// 사진: 웹 에디터처럼 글 번호를 먼저 받아 그 번호로 파일을 올리고, 같은 번호로 글을 등록하면 엔진이 파일을 글에 붙인다
		$document_srl = $photos ? self::uploadPhotos($mid, $photos) : null;
		if ($document_srl)
		{
			$content .= $document_srl['html'];
			$document_srl = $document_srl['srl'];
		}
		$vars = array(
			'document_srl' => $document_srl,
			'title' => mb_substr($title, 0, 250),
			'content' => $content,
			'category_srl' => Core::intParam('category_srl') ?: null,
			'is_secret' => Core::param('is_secret') ? 'Y' : null,
			// 웹 글쓰기 화면이 기본으로 보내는 값. 빠지면 엔진이 '댓글 금지'로 저장한다.
			'comment_status' => 'ALLOW',
		);
		if ($guest !== null)
		{
			$vars = array_merge($vars, $guest);
		}
		// 추가 항목(확장 변수): 새 앱이 extra_vars 로 보낸 값 (필수 확인은 엔진이 한다)
		ExtraVars::apply($vars, self::moduleSrl($mid));
		$oModule = Board::run($mid, 'procBoardInsertDocument', $vars);
		if ($document_srl)
		{
			// 글 등록 때 엔진이 센 첨부 수가 0으로 남아 첨부 목록에 안 보일 때가 있어 엔진 함수로 다시 센다 (두 엔진 모두 있는 이름)
			getController('document')->updateUploaedCount(array($document_srl));
		}
		return array('document_srl' => (int)$oModule->get('document_srl'));
	}

	/**
	 * 비회원이 글을 쓸 때 웹 글쓰기 화면과 같이 받는 항목 (이름·비밀번호 필수, 메일·홈페이지는 있으면).
	 * 로그인했으면 null. 비밀번호는 엔진이 암호로 바꿔 저장하고, 웹에서 그 글을 고치거나 지울 때 쓴다.
	 */
	private static function guestFields()
	{
		$logged_info = \Context::get('logged_info');
		if ($logged_info && $logged_info->member_srl)
		{
			return null;
		}
		$nick_name = trim((string)Core::param('nick_name'));
		$password = (string)Core::param('password');
		if ($nick_name === '' || trim($password) === '')
		{
			throw new ApiError(400, 'guest_info_required', \appapiText::t('이름과 비밀번호를 입력해 주세요.'));
		}
		$fields = array(
			'nick_name' => mb_substr($nick_name, 0, 40),
			'password' => $password,
		);
		$email = trim((string)Core::param('email_address'));
		if ($email !== '')
		{
			$fields['email_address'] = mb_substr($email, 0, 250);
		}
		$homepage = trim((string)Core::param('homepage'));
		if ($homepage !== '')
		{
			$fields['homepage'] = mb_substr($homepage, 0, 250);
		}
		return $fields;
	}

	/**
	 * 고칠 글의 원본: 저장된 HTML 그대로(화면용 변환 전). 앱 편집기는 base_url 기준으로 사진 주소를 풀어 보여 준다.
	 * 고칠 수 있는 사람(작성자·관리 권한)에게만 준다.
	 */
	public static function documentSource()
	{
		self::requireLoginOrPassword();
		$mid = self::visibleBoard();
		$oDocument = self::editableDocument($mid);
		$module_srl = (int)$oDocument->get('module_srl');
		$result = array(
			'document_srl' => (int)$oDocument->document_srl,
			'title' => (string)$oDocument->get('title'),
			'content' => (string)$oDocument->get('content'),
			// 지금 분류 (0 = 없음). 새 앱은 고치기 화면에서 분류를 바꿀 수 있다
			'category_srl' => (int)$oDocument->get('category_srl'),
			'base_url' => Core::$base_url,
			// 게시판 관리자만 공지·제목 굵게·제목 색을 바꿀 수 있다 (웹 쓰기 화면의 관리자 항목)
			'manage' => null,
			// 추가 항목(확장 변수) 정의와 지금 값 (board.extra_keys 와 같은 꼴, 값은 {idx: 글자})
			'extra_keys' => ExtraVars::keys($module_srl),
			'extra_values' => ExtraVars::values($oDocument),
			// 글이 있는 게시판 정보 (분류 목록·분류 필수 등, board 응답의 board 와 같은 꼴)
			'board' => Board::boardInfo(self::moduleObject($mid)),
			// 이 글에 사진을 더 붙일 수 있는지와 한도 (모듈 0.10.16~, 기능 edit_photos): 글쓰기와 같은 판단
			'upload' => self::uploadAllowed($mid),
		);
		if (self::isManager($mid))
		{
			$color = (string)$oDocument->get('title_color');
			$result['manage'] = array(
				'is_notice' => $oDocument->get('is_notice') === 'Y',
				'title_bold' => $oDocument->get('title_bold') === 'Y',
				'title_color' => ($color === '' || $color === 'N') ? '' : ltrim($color, '#'),
			);
		}
		return $result;
	}

	/** 이 게시판에 지금 사람이 사진을 올릴 수 있는지와 한도 (board.upload 와 같은 꼴) */
	private static function uploadAllowed($mid)
	{
		$module_info = getModel('module')->getModuleInfoByMid($mid);
		return Board::uploadInfo($module_info, Board::grant($module_info));
	}

	/** 이 게시판의 관리 권한 (엔진의 getGrant) */
	private static function isManager($mid)
	{
		$module_info = getModel('module')->getModuleInfoByMid($mid);
		return $module_info && !empty(Board::grant($module_info)->manager);
	}

	/**
	 * 글 고치기: 앱은 제목과 본문(HTML)만 바꾼다. 엔진의 글 고치기는 보내지 않은 항목을 지우거나 기본값으로 되돌리므로
	 * (추가 항목·태그·공지·제목 꾸밈·댓글 허용·비밀글·분류) 원래 값을 그대로 채워 보낸다.
	 * 고칠 권한·댓글 달린 글 보호·기간 보호·HTML 정리는 웹과 같이 엔진이 한다.
	 */
	/**
	 * 임시 저장: 웹 편집기의 "임시 저장"과 같은 엔진 동작(procDocumentTempSave). 저장한 글은 내 활동의 저장함에 나오고,
	 * 그 글 번호로 document.update 를 하면 엔진이 정식 글로 올린다. document_srl 을 주면 그 임시 글을 고친다.
	 */
	public static function tempSave()
	{
		$mid = self::writableBoard('write_document');
		$title = trim((string)Core::param('title'));
		$content = self::textToHtml(Core::param('content'));
		if ($title === '' && $content === '')
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('제목이나 내용을 입력해 주세요.'));
		}
		$oModule = Board::run($mid, 'procDocumentTempSave', array(
			'module' => 'document',
			'document_srl' => Core::intParam('document_srl') ?: null,
			'title' => mb_substr($title !== '' ? $title : '(제목 없음)', 0, 250),
			'content' => mb_substr($content, 0, 500000),
		), false, true);
		return array('document_srl' => (int)$oModule->get('document_srl'));
	}

	public static function updateDocument()
	{
		self::requireLoginOrPassword();
		$mid = self::visibleBoard();
		$oDocument = self::editableDocument($mid);
		$title = trim((string)Core::param('title'));
		$content = trim((string)Core::param('content'));
		// 새로 붙일 사진 (모듈 0.10.16~, 기능 edit_photos): 글쓰기와 같은 multipart photos[]
		$photos = self::uploadedPhotos();
		if ($title === '' || ($content === '' && !$photos))
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('제목과 내용을 입력해 주세요.'));
		}
		if ($photos)
		{
			// 웹 에디터의 글 고치기처럼 이 글 번호로 파일을 올리면, 글을 고칠 때 엔진이 첨부로 붙인다 (올리기 권한·크기 한도는 글쓰기와 같은 검사)
			$uploaded = self::uploadPhotos($mid, $photos, (int)$oDocument->document_srl);
			$content .= $uploaded['html'];
		}
		$vars = array(
			'document_srl' => (int)$oDocument->document_srl,
			'title' => mb_substr($title, 0, 250),
			'content' => mb_substr($content, 0, 500000),
			'category_srl' => (int)$oDocument->get('category_srl') ?: null,
			'is_secret' => $oDocument->get('status') === getModel('document')->getConfigStatus('secret') ? 'Y' : null,
			'tags' => (string)$oDocument->get('tags'),
			'is_notice' => (string)$oDocument->get('is_notice'),
			'title_color' => (string)$oDocument->get('title_color'),
			'title_bold' => (string)$oDocument->get('title_bold'),
			'comment_status' => (string)$oDocument->get('comment_status') ?: 'ALLOW',
			'allow_trackback' => (string)$oDocument->get('allow_trackback'),
			'notify_message' => (string)$oDocument->get('notify_message'),
		);
		// 공지·제목 꾸밈은 관리자가 보낸 값만 쓴다. 엔진이 막지 않는 사이트(코어를 고친 kgpa 등)가 있어 여기서 판단한다.
		if (self::isManager($mid))
		{
			if (Core::param('is_notice') !== null)
			{
				$vars['is_notice'] = Core::param('is_notice') === 'Y' ? 'Y' : 'N';
			}
			if (Core::param('title_bold') !== null)
			{
				$vars['title_bold'] = Core::param('title_bold') === 'Y' ? 'Y' : 'N';
			}
			if (Core::param('title_color') !== null)
			{
				$color = ltrim(trim((string)Core::param('title_color')), '#');
				$vars['title_color'] = preg_match('/^[0-9a-fA-F]{6}$/', $color) ? strtoupper($color) : 'N';
			}
		}
		foreach ((array)$oDocument->getExtraVars() as $extra)
		{
			if (isset($extra->idx) && $extra->value !== null && $extra->value !== '')
			{
				$vars['extra_vars' . (int)$extra->idx] = $extra->value;
			}
		}
		// 새 앱이 분류를 보냈으면 그것으로 (분류 권한·필수 확인은 엔진이 한다). 없으면(예전 앱) 원래 분류 그대로
		if (Core::param('category_srl') !== null)
		{
			$vars['category_srl'] = Core::intParam('category_srl') ?: null;
		}
		// 비밀번호로 고치는 비회원 글: 웹의 고치기 화면처럼 원래 이름·메일·홈페이지와 확인한 비밀번호를 같이 보낸다 (작성자 정보 유지)
		if (self::$byPassword)
		{
			$vars = array_merge($vars, self::guestOriginal($oDocument));
		}
		// 새 앱이 고친 추가 항목만 바꾼다 (보내지 않은 항목은 위의 원래 값 그대로)
		ExtraVars::apply($vars, (int)$oDocument->get('module_srl'));
		Board::run($mid, 'procBoardInsertDocument', $vars);
		if ($photos)
		{
			getController('document')->updateUploaedCount(array((int)$oDocument->document_srl));
		}
		return array('document_srl' => (int)$oDocument->document_srl);
	}

	/**
	 * 이 게시판의 글이고 현재 회원이 고칠 수 있는(작성자이거나 관리 권한) 글.
	 * 통합 게시판에서 연 글이면 $mid 를 그 글의 원래 게시판으로 바꾼다 (권한·설정은 원래 게시판 기준)
	 */
	private static function editableDocument(&$mid)
	{
		$document_srl = Core::intParam('document_srl');
		$oDocument = $document_srl ? getModel('document')->getDocument($document_srl) : null;
		$real = $oDocument && $oDocument->isExists() ? Board::documentBoard($mid, $oDocument) : null;
		if (!$real)
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		$mid = $real->mid;
		if (!$oDocument->isGranted() && !self::grantByPassword($oDocument, $real, 'write_document'))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		return $oDocument;
	}

	/** 이번 요청에서 비밀번호로 비회원 글·댓글의 권한을 받았는가 */
	private static $byPassword = false;

	/**
	 * 토큰도 비밀번호도 없으면 예전과 같이 401 login_required (이 route 들은 모듈 0.10.16 까지 로그인 필수였다)
	 */
	private static function requireLoginOrPassword()
	{
		if (!Auth::$token && (string)Core::param('password') === '')
		{
			throw new ApiError(401, 'login_required', Auth::lang('msg_not_logged'));
		}
	}

	/**
	 * 웹이 비밀번호를 물어 고치기·지우기를 허락하는 비회원 글·댓글인가 (모듈 0.10.17~, 응답의 password_edit).
	 * 웹(dispBoardWrite·dispBoardDelete·dispBoardModifyComment·dispBoardDeleteComment)과 같이: 회원 번호 0(익명 게시판의 음수 아님),
	 * 지금 권한이 없고, 게시판의 쓰기 권한(글 write_document, 댓글 write_comment)과 열람 권한(Rhymix 비밀번호 확인 동작의 조건)이 있을 때.
	 */
	public static function passwordEditable($oItem, $module_info, $grant_name)
	{
		if (!$oItem || !$oItem->isExists() || (int)$oItem->get('member_srl') !== 0 || (string)$oItem->get('password') === '' || $oItem->isGranted())
		{
			return false;
		}
		if (method_exists($oItem, 'isDeleted') && $oItem->isDeleted())
		{
			return false;
		}
		$grant = Board::grant($module_info);
		return !empty($grant->$grant_name) && !empty($grant->view);
	}

	/**
	 * 비회원 글·댓글의 비밀번호 확인 (모듈 0.10.17~). 웹의 procBoardVerificationPassword 와 같은 엔진 함수(회원 모델 isValidPassword)로
	 * 저장된 암호와 비교하고, 맞으면 엔진이 웹에서 하듯 그 글(댓글)을 '권한 있음'으로 표시한다(Rhymix setGrantForSession, XE setGrant).
	 * 앱 요청에는 쿠키 세션이 없고 응답 전에 세션을 버리므로(Core::endRequestSession) 이번 요청에만 해당한다.
	 * 비밀번호를 보내지 않았으면 false, 회원 글이거나 웹에서도 비밀번호 화면을 열 수 없으면 403 not_permitted, 틀리면 403 wrong_password.
	 * $grant_name: 웹에서 그 화면을 여는 데 필요한 게시판 권한 (write_document, write_comment, 비밀글 보기는 view)
	 */
	public static function grantByPassword($oItem, $module_info, $grant_name)
	{
		$password = (string)Core::param('password');
		if ($password === '')
		{
			return false;
		}
		$grant = Board::grant($module_info);
		if ((int)$oItem->get('member_srl') !== 0 || (string)$oItem->get('password') === '' || empty($grant->$grant_name) || empty($grant->view)
			|| (method_exists($oItem, 'isDeleted') && $oItem->isDeleted()))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		if (!getModel('member')->isValidPassword((string)$oItem->get('password'), $password))
		{
			throw new ApiError(403, 'wrong_password', \appapiText::t('비밀번호가 맞지 않습니다.'));
		}
		if (method_exists($oItem, 'setGrantForSession'))
		{
			$oItem->setGrantForSession();
		}
		else
		{
			$oItem->setGrant();
		}
		self::$byPassword = true;
		// 비회원이면 엔진의 같은 사이트 요청 검사를 통과시킨다 (비회원 글쓰기와 같은 이유: 쿠키가 없는 앱 요청은 CSRF 와 무관). 요청이 끝나면 사라진다
		Board::$allowGuestWrite = true;
		return true;
	}

	/** 비밀번호로 고치는 비회원 글·댓글: 원래 작성자 정보와 확인한 비밀번호 (웹의 고치기 양식이 보내는 값) */
	private static function guestOriginal($oItem)
	{
		$fields = array('password' => (string)Core::param('password'));
		foreach (array('nick_name', 'email_address', 'homepage') as $key)
		{
			$value = html_entity_decode((string)$oItem->get($key), ENT_QUOTES, 'UTF-8');
			if ($value !== '')
			{
				$fields[$key] = $value;
			}
		}
		return $fields;
	}

	/** multipart 의 photos[] (또는 photos 한 장). 정상 업로드가 아닌 것은 거절 */
	private static function uploadedPhotos()
	{
		if (empty($_FILES['photos']) || !isset($_FILES['photos']['tmp_name']))
		{
			return array();
		}
		$files = array();
		$f = $_FILES['photos'];
		foreach ((array)$f['tmp_name'] as $i => $tmp)
		{
			$one = is_array($f['tmp_name'])
				? array('name' => $f['name'][$i], 'type' => $f['type'][$i], 'tmp_name' => $tmp, 'error' => $f['error'][$i], 'size' => $f['size'][$i])
				: $f;
			if ((int)$one['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($one['tmp_name']))
			{
				throw new ApiError(400, 'upload_failed', \appapiText::t('사진을 받지 못했습니다. 크기가 너무 크면 작게 줄여서 다시 올려 주세요.'));
			}
			if (!@getimagesize($one['tmp_name']))
			{
				throw new ApiError(400, 'not_image', \appapiText::t('사진 파일만 올릴 수 있습니다.'));
			}
			$files[] = $one;
		}
		if (count($files) > 30)
		{
			throw new ApiError(400, 'too_many_photos', \appapiText::t('사진은 한 번에 30장까지 올릴 수 있습니다.'));
		}
		return $files;
	}

	/**
	 * 사진을 엔진(파일 모듈 procFileUpload)으로 올린다. 크기·형식 한도, Rhymix 의 자동 줄이기·회전·EXIF 지우기는 엔진 설정대로.
	 * $target_srl 이 있으면(글 고치기) 그 글에 붙이고, 없으면 새 글 번호를 받는다.
	 * @return array srl = 글 번호, html = 본문 끝에 붙일 이미지 태그 (웹 에디터가 넣는 것과 같은 모양)
	 */
	private static function uploadPhotos($mid, array $photos, $target_srl = 0)
	{
		$module_info = getModel('module')->getModuleInfoByMid($mid);
		if (!self::uploadAllowed($mid)['allowed'])
		{
			throw new ApiError(403, 'upload_not_permitted', \appapiText::t('이 게시판은 사진을 올릴 수 없습니다.'));
		}
		$srl = $target_srl ?: getNextSequence(); // 새 글 번호는 setUserSequence 도 함께 된다 (글 등록 때 엔진이 확인)
		if (Core::$engine === 'rhymix')
		{
			// 웹 에디터처럼 글 첨부('doc')로 표시해야 글 등록 때 첨부 수에 들어간다
			\FileController::setUploadInfo($srl, $srl, (int)$module_info->module_srl, array('upload_target_type' => 'doc'));
		}
		else
		{
			getController('file')->setUploadInfo($srl, $srl);
		}
		$width = (string)Core::param('photo_width');
		$style = $width === 'half' ? 'width:50%;height:auto;' : ($width === 'original' ? 'max-width:100%;height:auto;' : 'width:100%;height:auto;');
		$html = '';
		// 글 고치기면 이미 붙은 파일 다음 번호부터 (photo3.jpg …)
		$offset = $target_srl ? (int)getModel('file')->getFilesCount($srl) : 0;
		foreach ($photos as $index => $photo)
		{
			$name = 'photo' . ($offset + $index + 1) . '.jpg';
			$photo['name'] = $name;
			$_FILES['Filedata'] = $photo;
			\Context::set('Filedata', $photo, true);
			$oFile = Board::run($mid, 'procFileUpload', array('editor_sequence' => $srl, 'upload_target_srl' => $srl));
			$file_srl = (int)$oFile->get('file_srl');
			$url = (string)$oFile->get('download_url');
			if (!$file_srl || $url === '')
			{
				throw new ApiError(400, 'upload_failed', $oFile->getMessage() ? Auth::lang($oFile->getMessage()) : \appapiText::t('사진을 올리지 못했습니다.'));
			}
			$html .= '<p><img src="' . htmlspecialchars(Core::absoluteUrl($url), ENT_QUOTES, 'UTF-8') . '" alt="' . $name . '" editor_component="image_link" data-file-srl="' . $file_srl . '" style="' . $style . '" /></p>';
		}
		unset($_FILES['Filedata']);
		\Context::set('Filedata', null, true);
		return array('srl' => $srl, 'html' => $html);
	}

	public static function insertComment()
	{
		// 비회원 댓글 (모듈 0.10.17~, 기능 guest_comment): 토큰 없이 이름·비밀번호를 보낸다. 둘 다 없으면 예전과 같이 로그인 필요
		if (!Auth::$token && (string)Core::param('nick_name') === '' && (string)Core::param('password') === '')
		{
			throw new ApiError(401, 'login_required', Auth::lang('msg_not_logged'));
		}
		$mid = self::writableBoard('write_comment');
		$document_srl = Core::intParam('document_srl');
		$content = self::textToHtml(Core::param('content'));
		if (!$document_srl || $content === '')
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('댓글 내용을 입력해 주세요.'));
		}
		$guest = self::guestFields();
		$vars = array(
			'document_srl' => $document_srl,
			'parent_srl' => Core::intParam('parent_srl') ?: null,
			'content' => $content,
			'is_secret' => Core::param('is_secret') ? 'Y' : null,
		);
		Board::$allowGuestWrite = $guest !== null;
		try
		{
			$oModule = Board::run($mid, 'procBoardInsertComment', $guest !== null ? array_merge($vars, $guest) : $vars);
		}
		finally
		{
			Board::$allowGuestWrite = false;
		}
		$comment_srl = (int)$oModule->get('comment_srl');
		return array(
			'comment_srl' => $comment_srl,
			'document_srl' => $document_srl,
			// 댓글 승인제 게시판: 관리자가 승인하기 전까지 아무에게도 안 보인다 (엔진이 status 0 으로 저장)
			'pending' => $comment_srl > 0 && self::commentPending($comment_srl),
		);
	}

	public static function deleteDocument()
	{
		self::requireLoginOrPassword();
		$mid = self::visibleBoard();
		$document_srl = Core::intParam('document_srl');
		if (!$document_srl)
		{
			throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
		}
		// 엔진도 검사하지만, 남의 글을 지우는 사고를 막기 위해 여기서 먼저 확인한다:
		// 이 게시판의 글이고, 현재 회원이 작성자이거나 관리 권한이 있어야 한다.
		$oDocument = getModel('document')->getDocument($document_srl);
		// 통합 게시판에서 연 글이면 원래 게시판으로 지운다
		$real = ($oDocument && $oDocument->isExists()) ? Board::documentBoard($mid, $oDocument) : null;
		if (!$real)
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		$mid = $real->mid;
		// 비회원 글은 웹처럼 비밀번호로 (모듈 0.10.17~)
		if (!$oDocument->isGranted() && !self::grantByPassword($oDocument, $real, 'write_document'))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		try
		{
			Board::run($mid, 'procBoardDeleteDocument', array('document_srl' => $document_srl));
		}
		catch (ApiError $e)
		{
			// 일부 사이트는 삭제를 마친 뒤에도 '대상을 찾을 수 없습니다'를 낸다 (웹 화면도 같다).
			// 글이 실제로 없어졌을 때만 성공으로 본다.
			if (self::documentStillExists($document_srl))
			{
				throw $e;
			}
		}
		return array('deleted' => true);
	}

	public static function deleteComment()
	{
		self::requireLoginOrPassword();
		$mid = self::visibleBoard();
		$comment_srl = Core::intParam('comment_srl');
		if (!$comment_srl)
		{
			throw new ApiError(400, 'missing_comment_srl', 'comment_srl is required');
		}
		// 사전 확인: 이 게시판의 댓글이고, 현재 회원이 작성자이거나 관리 권한이 있어야 한다.
		$oComment = getModel('comment')->getComment($comment_srl);
		$real = ($oComment && $oComment->isExists()) ? Board::documentBoard($mid, $oComment) : null;
		if (!$real)
		{
			throw new ApiError(404, 'comment_not_found', Auth::lang('msg_not_founded'));
		}
		$mid = $real->mid;
		if (!$oComment->isGranted() && !self::grantByPassword($oComment, $real, 'write_comment'))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		Board::run($mid, 'procBoardDeleteComment', array('comment_srl' => $comment_srl));
		return array('deleted' => true);
	}

	/**
	 * 댓글 고치기 (모듈 0.10.17~, 기능 comment_edit): 웹의 댓글 수정과 같은 엔진 동작(procBoardInsertComment 에 comment_srl).
	 * 앱은 일반 글자로 보낸다(댓글 쓰기와 같은 변환). 비밀 댓글 표시·알림 설정은 원래 값 그대로. 비회원 댓글은 비밀번호로.
	 * 고칠 권한·답글 달린 댓글 보호·기간 보호는 엔진이 웹과 같이 한다.
	 */
	public static function updateComment()
	{
		self::requireLoginOrPassword();
		$mid = self::visibleBoard();
		$comment_srl = Core::intParam('comment_srl');
		$content = self::textToHtml(Core::param('content'));
		if (!$comment_srl || $content === '')
		{
			throw new ApiError(400, 'missing_content', \appapiText::t('댓글 내용을 입력해 주세요.'));
		}
		$oComment = getModel('comment')->getComment($comment_srl);
		$real = ($oComment && $oComment->isExists()) ? Board::documentBoard($mid, $oComment) : null;
		if (!$real)
		{
			throw new ApiError(404, 'comment_not_found', Auth::lang('msg_not_founded'));
		}
		$mid = $real->mid;
		if (!$oComment->isGranted() && !self::grantByPassword($oComment, $real, 'write_comment'))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		if (empty(Board::grant($real)->write_comment))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		$document_srl = (int)$oComment->get('document_srl');
		$vars = array(
			'document_srl' => $document_srl,
			'comment_srl' => $comment_srl,
			'content' => $content,
			'is_secret' => $oComment->isSecret() ? 'Y' : null,
			'notify_message' => $oComment->get('notify_message') === 'Y' ? 'Y' : null,
		);
		if (self::$byPassword)
		{
			$vars = array_merge($vars, self::guestOriginal($oComment));
		}
		Board::run($mid, 'procBoardInsertComment', $vars);
		return array('comment_srl' => $comment_srl, 'document_srl' => $document_srl);
	}

	/**
	 * 읽을 수 있고 해당 쓰기 권한도 있는 게시판의 mid. 아니면 오류 (엔진도 다시 검사한다).
	 */
	private static function writableBoard($permission)
	{
		$mid = self::visibleBoard();
		$grant = Board::grant(getModel('module')->getModuleInfoByMid($mid));
		if (empty($grant->$permission))
		{
			// 비회원이면 401: 앱이 로그인을 권한다 (Board::run 과 같다)
			$logged_info = \Context::get('logged_info');
			throw new ApiError(($logged_info && $logged_info->member_srl) ? 403 : 401, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		return $mid;
	}

	/**
	 * 캐시를 거치지 않고 DB 에서 직접: 글이 남아 있고 휴지통 상태도 아니면 true.
	 */
	private static function documentStillExists($document_srl)
	{
		$stmt = Core::pdo()->prepare('SELECT status FROM `' . Core::tablePrefix() . 'documents` WHERE document_srl = ?');
		$stmt->execute(array($document_srl));
		$row = $stmt->fetch();
		return $row && strtoupper((string)$row['status']) !== 'TRASH';
	}

	/** boardInfo 에 넘길 모듈 정보·권한 */
	private static function moduleObject($mid)
	{
		$module_info = getModel('module')->getModuleInfoByMid($mid);
		$object = new \stdClass;
		$object->module_info = $module_info;
		$object->grant = Board::grant($module_info);
		return $object;
	}

	/** 댓글이 승인 대기(status 0)인가. 캐시를 거치지 않고 DB 에서 */
	private static function commentPending($comment_srl)
	{
		try
		{
			$stmt = Core::pdo()->prepare('SELECT status FROM `' . Core::tablePrefix() . 'comments` WHERE comment_srl = ?');
			$stmt->execute(array($comment_srl));
			$status = $stmt->fetchColumn();
			return $status !== false && $status !== null && (int)$status === 0;
		}
		catch (\Throwable $e)
		{
			return false; // status 칸이 없는 아주 예전 엔진
		}
	}

	private static function moduleSrl($mid)
	{
		return (int)getModel('module')->getModuleInfoByMid($mid)->module_srl;
	}

	private static function visibleBoard()
	{
		$mid = (string)Core::param('mid');
		$module_info = preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid) ? getModel('module')->getModuleInfoByMid($mid) : null;
		if (!$module_info || $module_info->module !== 'board' || !Board::canReadBoard($module_info))
		{
			throw new ApiError(404, 'board_not_found', Auth::lang('msg_not_founded'));
		}
		return $mid;
	}

	/**
	 * 앱 꾸밈 편집기의 HTML. 글자·사진이 하나도 없으면(빈 줄만) 빈 본문으로 본다.
	 */
	private static function editorHtml($html)
	{
		$html = trim((string)$html);
		$visible = trim(str_replace(array('&nbsp;', "\xC2\xA0"), ' ', strip_tags($html, '<img><video><iframe><embed><object>')));
		if ($visible === '')
		{
			return '';
		}
		return mb_substr($html, 0, 500000);
	}

	/**
	 * 앱이 보낸 일반 글자를 본문 HTML 로: 태그는 글자로 보이게 하고 줄바꿈은 살린다.
	 */
	private static function textToHtml($text)
	{
		$text = trim(str_replace(array("\r\n", "\r"), "\n", (string)$text));
		if ($text === '')
		{
			return '';
		}
		return nl2br(htmlspecialchars(mb_substr($text, 0, 50000), ENT_QUOTES, 'UTF-8'));
	}
}
