<?php
/**
 * 사이트별 설정. config.php 로 복사해 고친다 (없으면 기본값으로 동작).
 */
return array(
	// 앱에 보일 사이트 이름·대표 색·로고 (비우면 시작 모듈의 브라우저 제목을 쓴다)
	'site_name' => '',
	'theme_color' => '',   // 예: '#1F6FEB'
	'logo_url' => '',      // 예: '/files/attach/logo.png'

	// 토큰 수명(초)
	'access_ttl' => 3600,
	'refresh_ttl' => 86400 * 365,

	// 게시판별 목록 모양 지정: list | gallery | webzine | calendar (없으면 스킨 설정에서 추정)
	'board_styles' => array(
		// 'gallary' => 'gallery',
	),
);
