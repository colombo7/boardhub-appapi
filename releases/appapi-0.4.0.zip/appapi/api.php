<?php
/**
 * BoardHub 앱 API 진입점.
 *
 * modules/appapi 모듈로 설치한다. 호출: /modules/appapi/api.php?r=<route> (예전 주소 /appapi/index.php 도 연결 파일로 지원)
 * 구 XE 1.x(PHP 7.1)와 Rhymix 2.x 모두에서 동작해야 하므로 PHP 7.1 문법만 쓴다.
 */

define('APPAPI_VERSION', '0.4.0');
define('APPAPI_DIR', __DIR__);

require APPAPI_DIR . '/lib/Response.php';
require APPAPI_DIR . '/lib/Core.php';
require APPAPI_DIR . '/lib/Tokens.php';
require APPAPI_DIR . '/lib/Auth.php';
require APPAPI_DIR . '/lib/Board.php';
require APPAPI_DIR . '/lib/Write.php';
require APPAPI_DIR . '/lib/Member.php';
require APPAPI_DIR . '/lib/Actions.php';
require APPAPI_DIR . '/lib/Menu.php';
require APPAPI_DIR . '/lib/Router.php';

AppApi\Router::run();
