<?php
namespace AppApi;

/**
 * 글·댓글 쓰기와 삭제.
 *
 * 웹과 같은 게시판 액션(procBoardInsertDocument 등)을 실행하므로 쓰기 권한, 본인 확인, 스팸 방지,
 * 포인트, 알림 같은 규칙을 엔진이 그대로 적용한다. 앱은 일반 글자로 보내고 여기서 HTML 로 바꾼다.
 */
class Write
{
	public static function insertDocument()
	{
		$mid = self::writableBoard('write_document');
		$title = trim((string)Core::param('title'));
		$content = self::textToHtml(Core::param('content'));
		$photos = self::uploadedPhotos();
		if ($title === '' || ($content === '' && !$photos))
		{
			throw new ApiError(400, 'missing_content', '제목과 내용을 입력해 주세요.');
		}
		// 사진: 웹 에디터처럼 글 번호를 먼저 받아 그 번호로 파일을 올리고, 같은 번호로 글을 등록하면 엔진이 파일을 글에 붙인다
		$document_srl = $photos ? self::uploadPhotos($mid, $photos) : null;
		if ($document_srl)
		{
			$content .= $document_srl['html'];
			$document_srl = $document_srl['srl'];
		}
		$oModule = Board::run($mid, 'procBoardInsertDocument', array(
			'document_srl' => $document_srl,
			'title' => mb_substr($title, 0, 250),
			'content' => $content,
			'category_srl' => Core::intParam('category_srl') ?: null,
			'is_secret' => Core::param('is_secret') ? 'Y' : null,
			// 웹 글쓰기 화면이 기본으로 보내는 값. 빠지면 엔진이 '댓글 금지'로 저장한다.
			'comment_status' => 'ALLOW',
		));
		if ($document_srl)
		{
			// 글 등록 때 엔진이 센 첨부 수가 0으로 남아 첨부 목록에 안 보일 때가 있어 엔진 함수로 다시 센다 (두 엔진 모두 있는 이름)
			getController('document')->updateUploaedCount(array($document_srl));
		}
		return array('document_srl' => (int)$oModule->get('document_srl'));
	}

	/** multipart 의 photos[] (또는 photos 한 장). 정상 업로드가 아닌 것은 거절 */
	private static function uploadedPhotos()
	{
		if (empty($_FILES['photos']) || !isset($_FILES['photos']['tmp_name']))
		{
			return array();
		}
		$files = array();
		$f = $_FILES['photos'];
		foreach ((array)$f['tmp_name'] as $i => $tmp)
		{
			$one = is_array($f['tmp_name'])
				? array('name' => $f['name'][$i], 'type' => $f['type'][$i], 'tmp_name' => $tmp, 'error' => $f['error'][$i], 'size' => $f['size'][$i])
				: $f;
			if ((int)$one['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($one['tmp_name']))
			{
				throw new ApiError(400, 'upload_failed', '사진을 받지 못했습니다. 크기가 너무 크면 작게 줄여서 다시 올려 주세요.');
			}
			if (!@getimagesize($one['tmp_name']))
			{
				throw new ApiError(400, 'not_image', '사진 파일만 올릴 수 있습니다.');
			}
			$files[] = $one;
		}
		if (count($files) > 30)
		{
			throw new ApiError(400, 'too_many_photos', '사진은 한 번에 30장까지 올릴 수 있습니다.');
		}
		return $files;
	}

	/**
	 * 사진을 엔진(파일 모듈 procFileUpload)으로 올린다. 크기·형식 한도, Rhymix 의 자동 줄이기·회전·EXIF 지우기는 엔진 설정대로.
	 * @return array srl = 새 글 번호, html = 본문 끝에 붙일 이미지 태그 (웹 에디터가 넣는 것과 같은 모양)
	 */
	private static function uploadPhotos($mid, array $photos)
	{
		$module_info = getModel('module')->getModuleInfoByMid($mid);
		if (!Board::uploadInfo($module_info, Board::grant($module_info))['allowed'])
		{
			throw new ApiError(403, 'upload_not_permitted', '이 게시판은 사진을 올릴 수 없습니다.');
		}
		$srl = getNextSequence(); // setUserSequence 도 함께 된다 (글 등록 때 엔진이 확인)
		if (Core::$engine === 'rhymix')
		{
			// 웹 에디터처럼 글 첨부('doc')로 표시해야 글 등록 때 첨부 수에 들어간다
			\FileController::setUploadInfo($srl, $srl, (int)$module_info->module_srl, array('upload_target_type' => 'doc'));
		}
		else
		{
			getController('file')->setUploadInfo($srl, $srl);
		}
		$width = (string)Core::param('photo_width');
		$style = $width === 'half' ? 'width:50%;height:auto;' : ($width === 'original' ? 'max-width:100%;height:auto;' : 'width:100%;height:auto;');
		$html = '';
		foreach ($photos as $index => $photo)
		{
			$name = 'photo' . ($index + 1) . '.jpg';
			$photo['name'] = $name;
			$_FILES['Filedata'] = $photo;
			\Context::set('Filedata', $photo, true);
			$oFile = Board::run($mid, 'procFileUpload', array('editor_sequence' => $srl, 'upload_target_srl' => $srl));
			$file_srl = (int)$oFile->get('file_srl');
			$url = (string)$oFile->get('download_url');
			if (!$file_srl || $url === '')
			{
				throw new ApiError(400, 'upload_failed', $oFile->getMessage() ? Auth::lang($oFile->getMessage()) : '사진을 올리지 못했습니다.');
			}
			$html .= '<p><img src="' . htmlspecialchars(Core::absoluteUrl($url), ENT_QUOTES, 'UTF-8') . '" alt="' . $name . '" editor_component="image_link" data-file-srl="' . $file_srl . '" style="' . $style . '" /></p>';
		}
		unset($_FILES['Filedata']);
		\Context::set('Filedata', null, true);
		return array('srl' => $srl, 'html' => $html);
	}

	public static function insertComment()
	{
		$mid = self::writableBoard('write_comment');
		$document_srl = Core::intParam('document_srl');
		$content = self::textToHtml(Core::param('content'));
		if (!$document_srl || $content === '')
		{
			throw new ApiError(400, 'missing_content', '댓글 내용을 입력해 주세요.');
		}
		$oModule = Board::run($mid, 'procBoardInsertComment', array(
			'document_srl' => $document_srl,
			'parent_srl' => Core::intParam('parent_srl') ?: null,
			'content' => $content,
			'is_secret' => Core::param('is_secret') ? 'Y' : null,
		));
		return array('comment_srl' => (int)$oModule->get('comment_srl'), 'document_srl' => $document_srl);
	}

	public static function deleteDocument()
	{
		$mid = self::visibleBoard();
		$document_srl = Core::intParam('document_srl');
		if (!$document_srl)
		{
			throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
		}
		// 엔진도 검사하지만, 남의 글을 지우는 사고를 막기 위해 여기서 먼저 확인한다:
		// 이 게시판의 글이고, 현재 회원이 작성자이거나 관리 권한이 있어야 한다.
		$oDocument = getModel('document')->getDocument($document_srl);
		if (!$oDocument || !$oDocument->isExists() || (int)$oDocument->get('module_srl') !== self::moduleSrl($mid))
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		if (!$oDocument->isGranted())
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		try
		{
			Board::run($mid, 'procBoardDeleteDocument', array('document_srl' => $document_srl));
		}
		catch (ApiError $e)
		{
			// 일부 사이트는 삭제를 마친 뒤에도 '대상을 찾을 수 없습니다'를 낸다 (웹 화면도 같다).
			// 글이 실제로 없어졌을 때만 성공으로 본다.
			if (self::documentStillExists($document_srl))
			{
				throw $e;
			}
		}
		return array('deleted' => true);
	}

	public static function deleteComment()
	{
		$mid = self::visibleBoard();
		$comment_srl = Core::intParam('comment_srl');
		if (!$comment_srl)
		{
			throw new ApiError(400, 'missing_comment_srl', 'comment_srl is required');
		}
		// 사전 확인: 이 게시판의 댓글이고, 현재 회원이 작성자이거나 관리 권한이 있어야 한다.
		$oComment = getModel('comment')->getComment($comment_srl);
		if (!$oComment || !$oComment->isExists() || (int)$oComment->get('module_srl') !== self::moduleSrl($mid))
		{
			throw new ApiError(404, 'comment_not_found', Auth::lang('msg_not_founded'));
		}
		if (!$oComment->isGranted())
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		Board::run($mid, 'procBoardDeleteComment', array('comment_srl' => $comment_srl));
		return array('deleted' => true);
	}

	/**
	 * 읽을 수 있고 해당 쓰기 권한도 있는 게시판의 mid. 아니면 오류 (엔진도 다시 검사한다).
	 */
	private static function writableBoard($permission)
	{
		$mid = self::visibleBoard();
		$grant = Board::grant(getModel('module')->getModuleInfoByMid($mid));
		if (empty($grant->$permission))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		return $mid;
	}

	/**
	 * 캐시를 거치지 않고 DB 에서 직접: 글이 남아 있고 휴지통 상태도 아니면 true.
	 */
	private static function documentStillExists($document_srl)
	{
		$stmt = Core::pdo()->prepare('SELECT status FROM `' . Core::tablePrefix() . 'documents` WHERE document_srl = ?');
		$stmt->execute(array($document_srl));
		$row = $stmt->fetch();
		return $row && strtoupper((string)$row['status']) !== 'TRASH';
	}

	private static function moduleSrl($mid)
	{
		return (int)getModel('module')->getModuleInfoByMid($mid)->module_srl;
	}

	private static function visibleBoard()
	{
		$mid = (string)Core::param('mid');
		$module_info = preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid) ? getModel('module')->getModuleInfoByMid($mid) : null;
		if (!$module_info || $module_info->module !== 'board' || !Board::canReadBoard($module_info))
		{
			throw new ApiError(404, 'board_not_found', Auth::lang('msg_not_founded'));
		}
		return $mid;
	}

	/**
	 * 앱이 보낸 일반 글자를 본문 HTML 로: 태그는 글자로 보이게 하고 줄바꿈은 살린다.
	 */
	private static function textToHtml($text)
	{
		$text = trim(str_replace(array("\r\n", "\r"), "\n", (string)$text));
		if ($text === '')
		{
			return '';
		}
		return nl2br(htmlspecialchars(mb_substr($text, 0, 50000), ENT_QUOTES, 'UTF-8'));
	}
}
