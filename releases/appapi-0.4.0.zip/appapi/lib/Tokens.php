<?php
namespace AppApi;

/**
 * 기기별 로그인 토큰 저장소 (<prefix>appapi_tokens).
 *
 * - 접근 토큰: 짧은 수명. 요청마다 Authorization: Bearer 로 보낸다.
 * - 갱신 토큰: 긴 수명. 쓸 때마다 새로 발급(회전)하고 기한을 연장한다.
 * - 원문은 저장하지 않고 SHA-256 해시만 저장한다.
 * - 회전 직후 응답이 유실돼도 로그아웃되지 않도록, 새 토큰이 처음 쓰일 때까지 직전 갱신 토큰을 한 번 더 받아준다.
 */
class Tokens
{
	private static function table()
	{
		return Core::tablePrefix() . 'appapi_tokens';
	}

	public static function ensureTable()
	{
		Core::pdo()->exec('CREATE TABLE IF NOT EXISTS `' . self::table() . '` (
			`token_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
			`member_srl` BIGINT NOT NULL,
			`access_hash` CHAR(64) NOT NULL,
			`access_expires` INT UNSIGNED NOT NULL,
			`refresh_hash` CHAR(64) NOT NULL,
			`prev_refresh_hash` CHAR(64) NULL,
			`refresh_expires` INT UNSIGNED NOT NULL,
			`password_sig` CHAR(64) NOT NULL,
			`device_name` VARCHAR(100) NOT NULL DEFAULT \'\',
			`platform` VARCHAR(20) NOT NULL DEFAULT \'\',
			`ipaddress` VARCHAR(64) NOT NULL DEFAULT \'\',
			`created` INT UNSIGNED NOT NULL,
			`last_used` INT UNSIGNED NOT NULL,
			PRIMARY KEY (`token_id`),
			UNIQUE KEY `uk_access` (`access_hash`),
			UNIQUE KEY `uk_refresh` (`refresh_hash`),
			KEY `idx_prev_refresh` (`prev_refresh_hash`),
			KEY `idx_member` (`member_srl`)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8');
	}

	/**
	 * 회원 비밀번호 해시에서 만든 서명. 비밀번호가 바뀌면 달라져 기존 토큰이 무효가 된다.
	 */
	public static function passwordSig($password_hash)
	{
		return hash('sha256', 'appapi|' . $password_hash);
	}

	private static function newToken()
	{
		return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
	}

	private static function hash($token)
	{
		return hash('sha256', (string)$token);
	}

	private static function tokenPair()
	{
		return array(self::newToken(), self::newToken());
	}

	private static function output($access, $refresh)
	{
		return array(
			'access_token' => $access,
			'access_expires_in' => (int)Core::config('access_ttl'),
			'refresh_token' => $refresh,
			'refresh_expires_in' => (int)Core::config('refresh_ttl'),
		);
	}

	public static function issue($member_srl, $password_hash, $device_name, $platform)
	{
		self::ensureTable();
		list($access, $refresh) = self::tokenPair();
		$now = time();
		$stmt = Core::pdo()->prepare('INSERT INTO `' . self::table() . '`
			(member_srl, access_hash, access_expires, refresh_hash, refresh_expires, password_sig, device_name, platform, ipaddress, created, last_used)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
		$stmt->execute(array(
			$member_srl, self::hash($access), $now + Core::config('access_ttl'),
			self::hash($refresh), $now + Core::config('refresh_ttl'),
			self::passwordSig($password_hash),
			mb_substr((string)$device_name, 0, 100), mb_substr((string)$platform, 0, 20),
			$_SERVER['REMOTE_ADDR'], $now, $now,
		));
		if (mt_rand(1, 50) === 1)
		{
			self::cleanup();
		}
		return self::output($access, $refresh);
	}

	/**
	 * 유효한 접근 토큰의 행을 돌려준다. 만료됐거나 없으면 null.
	 */
	public static function findByAccess($access)
	{
		try
		{
			$stmt = Core::pdo()->prepare('SELECT * FROM `' . self::table() . '` WHERE access_hash = ?');
			$stmt->execute(array(self::hash($access)));
		}
		catch (\PDOException $e)
		{
			return null; // 테이블이 아직 없음 = 발급된 토큰 없음
		}
		$row = $stmt->fetch();
		if (!$row || $row['access_expires'] < time())
		{
			return null;
		}
		return $row;
	}

	/**
	 * 새 접근 토큰이 처음 쓰였으니 직전 갱신 토큰은 더 이상 받지 않는다.
	 */
	public static function touch($row)
	{
		$now = time();
		if ($row['prev_refresh_hash'] !== null || $row['last_used'] < $now - 60)
		{
			$stmt = Core::pdo()->prepare('UPDATE `' . self::table() . '` SET last_used = ?, prev_refresh_hash = NULL WHERE token_id = ?');
			$stmt->execute(array($now, $row['token_id']));
		}
	}

	/**
	 * 갱신 토큰으로 새 토큰 쌍을 발급한다. 실패하면 null.
	 * @return array|null [행, 새 토큰 출력]
	 */
	public static function rotate($refresh)
	{
		$hash = self::hash($refresh);
		try
		{
			$stmt = Core::pdo()->prepare('SELECT * FROM `' . self::table() . '` WHERE refresh_hash = ? OR prev_refresh_hash = ?');
			$stmt->execute(array($hash, $hash));
		}
		catch (\PDOException $e)
		{
			return null;
		}
		$row = $stmt->fetch();
		if (!$row || $row['refresh_expires'] < time())
		{
			return null;
		}

		list($access, $new_refresh) = self::tokenPair();
		$now = time();
		$stmt = Core::pdo()->prepare('UPDATE `' . self::table() . '`
			SET access_hash = ?, access_expires = ?, refresh_hash = ?, prev_refresh_hash = ?, refresh_expires = ?, ipaddress = ?, last_used = ?
			WHERE token_id = ?');
		$stmt->execute(array(
			self::hash($access), $now + Core::config('access_ttl'),
			self::hash($new_refresh), $row['refresh_hash'], $now + Core::config('refresh_ttl'),
			$_SERVER['REMOTE_ADDR'], $now, $row['token_id'],
		));
		return array($row, self::output($access, $new_refresh));
	}

	public static function revoke($token_id)
	{
		$stmt = Core::pdo()->prepare('DELETE FROM `' . self::table() . '` WHERE token_id = ?');
		$stmt->execute(array($token_id));
	}

	public static function revokeMember($member_srl)
	{
		$stmt = Core::pdo()->prepare('DELETE FROM `' . self::table() . '` WHERE member_srl = ?');
		$stmt->execute(array($member_srl));
	}

	private static function cleanup()
	{
		$stmt = Core::pdo()->prepare('DELETE FROM `' . self::table() . '` WHERE refresh_expires < ?');
		$stmt->execute(array(time()));
	}
}
