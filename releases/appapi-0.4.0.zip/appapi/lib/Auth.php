<?php
namespace AppApi;

/**
 * 로그인·토큰 갱신·로그아웃·요청 인증.
 */
class Auth
{
	/** @var array|null 현재 요청의 토큰 행 */
	public static $token;

	public static function login()
	{
		$user_id = trim((string)Core::param('user_id'));
		$password = (string)Core::param('password');
		if ($user_id === '' || $password === '')
		{
			throw new ApiError(400, 'missing_credentials', \Context::getLang('null_user_id'));
		}

		// 웹 로그인과 같은 함수: IP별 실패 제한, 차단·정지 회원, 로그인 트리거가 사이트 설정대로 적용된다.
		$output = getController('member')->doLogin($user_id, $password, false);
		if (!$output || !$output->toBool())
		{
			$message = $output ? $output->getMessage() : 'invalid_user_id';
			throw new ApiError(401, 'login_failed', self::lang($message));
		}
		$logged_info = \Context::get('logged_info');
		$member = self::memberRow($logged_info ? $logged_info->member_srl : 0);
		if (!$member)
		{
			throw new ApiError(401, 'login_failed', self::lang('invalid_user_id'));
		}

		// Rhymix 는 관리자 허용 IP 밖에서의 로그인을 거부한다(procMemberLogin). 웹과 똑같이 맞춘다.
		if (Core::$engine === 'rhymix' && $member['is_admin'] === 'Y' && !getAdminModel('member')->getMemberAdminIPCheck())
		{
			throw new ApiError(403, 'admin_ip_not_allowed', self::lang('msg_admin_ip_not_allowed'));
		}

		$tokens = Tokens::issue($member['member_srl'], $member['password'], Core::param('device_name', ''), Core::param('platform', ''));
		return array('tokens' => $tokens, 'member' => self::profile());
	}

	public static function refresh()
	{
		$result = Tokens::rotate((string)Core::param('refresh_token'));
		if (!$result)
		{
			throw new ApiError(401, 'refresh_invalid', 'login required');
		}
		list($row, $tokens) = $result;
		self::checkMember($row);
		return array('tokens' => $tokens);
	}

	public static function logout()
	{
		$row = Tokens::findByAccess(self::bearer());
		if (!$row && Core::param('refresh_token'))
		{
			$result = Tokens::rotate((string)Core::param('refresh_token'));
			$row = $result ? $result[0] : null;
		}
		if ($row)
		{
			Tokens::revoke($row['token_id']);
		}
		return array('logged_out' => true);
	}

	/**
	 * Authorization: Bearer 토큰으로 회원을 확인하고, 이번 요청 동안 로그인 상태를 만든다.
	 * $required 가 false 면 토큰이 없을 때 비회원으로 진행한다.
	 */
	public static function authenticate($required)
	{
		$access = self::bearer();
		if ($access === '')
		{
			if ($required)
			{
				throw new ApiError(401, 'login_required', self::lang('msg_not_logged'));
			}
			return false;
		}

		$row = Tokens::findByAccess($access);
		if (!$row)
		{
			// 앱은 이 코드를 받으면 갱신 토큰으로 새 접근 토큰을 받아 다시 시도한다.
			throw new ApiError(401, 'token_expired', 'access token expired');
		}
		self::checkMember($row);
		if (!Core::loginAs((int)$row['member_srl']))
		{
			Tokens::revoke($row['token_id']);
			throw new ApiError(401, 'session_revoked', self::lang('msg_not_logged'));
		}
		Tokens::touch($row);
		self::$token = $row;
		return true;
	}

	/**
	 * 회원 상태를 매번 다시 확인한다: 탈퇴·차단·비밀번호 변경이면 토큰 폐기, 기간 정지면 거부.
	 */
	private static function checkMember($row)
	{
		$member = self::memberRow($row['member_srl']);
		if (!$member || $member['denied'] === 'Y')
		{
			Tokens::revokeMember($row['member_srl']);
			throw new ApiError(401, 'session_revoked', self::lang('msg_user_denied'));
		}
		if (!hash_equals($row['password_sig'], Tokens::passwordSig($member['password'])))
		{
			Tokens::revoke($row['token_id']);
			throw new ApiError(401, 'session_revoked', 'password changed');
		}
		if ($member['limit_date'] && substr($member['limit_date'], 0, 8) >= date('Ymd'))
		{
			throw new ApiError(403, 'member_limited', sprintf(self::lang('msg_user_limited'), zdate($member['limit_date'], 'Y-m-d')));
		}
	}

	private static function memberRow($member_srl)
	{
		if (!$member_srl)
		{
			return null;
		}
		$stmt = Core::pdo()->prepare('SELECT member_srl, password, denied, limit_date, is_admin FROM `' . Core::tablePrefix() . 'member` WHERE member_srl = ?');
		$stmt->execute(array($member_srl));
		return $stmt->fetch() ?: null;
	}

	private static function bearer()
	{
		$header = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
		if (preg_match('/^Bearer\s+(\S+)$/i', $header, $m))
		{
			return $m[1];
		}
		return (string)($_SERVER['HTTP_X_APPAPI_TOKEN'] ?? '');
	}

	public static function lang($code)
	{
		$text = \Context::getLang($code);
		return is_string($text) && $text !== '' ? $text : $code;
	}

	/**
	 * 현재 로그인한 회원 정보 (앱 '내 정보' 화면용).
	 */
	public static function profile()
	{
		$info = \Context::get('logged_info');
		if (!$info || !$info->member_srl)
		{
			return null;
		}
		$image = getModel('member')->getProfileImage($info->member_srl);
		return array(
			'member_srl' => (int)$info->member_srl,
			'user_id' => $info->user_id,
			'nick_name' => $info->nick_name,
			'email_address' => $info->email_address,
			'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			'groups' => array_values((array)$info->group_list),
			'is_admin' => $info->is_admin === 'Y',
		);
	}
}
