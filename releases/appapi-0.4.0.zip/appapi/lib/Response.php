<?php
namespace AppApi;

/**
 * API 오류. Router 가 잡아서 JSON 오류 응답으로 바꾼다.
 */
class ApiError extends \Exception
{
	public $status;
	public $error_code;

	public function __construct($status, $error_code, $message = '')
	{
		parent::__construct($message ?: $error_code);
		$this->status = $status;
		$this->error_code = $error_code;
	}
}

class Response
{
	/**
	 * 성공 응답을 보내고 끝낸다.
	 */
	public static function ok($data, $status = 200)
	{
		self::send($status, array('ok' => true, 'data' => $data));
	}

	public static function error($status, $error_code, $message)
	{
		self::send($status, array('ok' => false, 'error' => array('code' => $error_code, 'message' => $message)));
	}

	private static function send($status, $body)
	{
		// 코어나 애드온이 흘린 출력은 버린다.
		while (ob_get_level() > 0)
		{
			ob_end_clean();
		}
		Core::endRequestSession();
		if (!headers_sent())
		{
			// 코어가 리다이렉트하려고 남긴 헤더는 지운다.
			header_remove('Location');
			http_response_code($status);
			header('Content-Type: application/json; charset=utf-8');
			header('Cache-Control: no-store');
			header('X-Content-Type-Options: nosniff');
		}
		echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		exit;
	}
}
