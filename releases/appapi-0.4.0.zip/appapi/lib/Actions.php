<?php
namespace AppApi;

/**
 * 글 아래 기능: 추천·비추천(취소), 추천인 목록, 스크랩, 신고.
 *
 * 쓸 수 있는지는 게시판(문서 모듈) 설정을 따르고(추천: 사용 Y / 사용·추천인 공개 S / 사용 안 함 N),
 * 실제 처리는 웹과 같은 엔진 함수로 한다. 엔진의 추천·추천인 목록 함수는 글을 읽을 권한을 보지 않으므로
 * 여기서 먼저 읽을 수 있는 글인지 확인한다.
 */
class Actions
{
	/** 글 보기 응답에 넣는 기능 상태 */
	public static function forDocument($oDocument)
	{
		$config = self::config($oDocument);
		$logged_info = \Context::get('logged_info');
		$member_srl = $logged_info && $logged_info->member_srl ? (int)$logged_info->member_srl : 0;
		$is_rhymix = Core::$engine === 'rhymix';
		// 추천인 표시 애드온이 이 게시판에서 돌면 웹 글 아래에 추천인이 늘 보이므로 앱도 공개로 다룬다
		$addon = self::voterAddonRuns((int)$oDocument->get('module_srl'));
		$up = self::state($config->use_vote_up ?? 'Y', (int)$oDocument->get('voted_count'));
		if ($addon && $up['enabled'])
		{
			$up['public'] = true;
		}
		return array(
			'vote_up' => $up,
			'vote_down' => self::state($config->use_vote_down ?? 'Y', abs((int)$oDocument->get('blamed_count'))),
			// 1 = 추천함, -1 = 비추천함, 0 = 안 함
			'my_vote' => $member_srl ? self::myVote((int)$oDocument->document_srl, $member_srl) : 0,
			// 추천 취소는 Rhymix 에서 게시판이 허용할 때만 (XE 에는 취소 기능이 없다)
			'can_cancel_vote' => $is_rhymix && ($config->allow_vote_cancel ?? 'N') === 'Y',
			'is_mine' => $member_srl && (int)$oDocument->get('member_srl') === $member_srl,
			'can_scrap' => (bool)$member_srl,
			'can_declare' => (bool)$member_srl && (int)$oDocument->get('member_srl') !== $member_srl,
		);
	}

	/** 추천(point=1) · 비추천(point=-1). cancel=1 이면 취소 */
	public static function vote()
	{
		$oDocument = self::readableDocument();
		$point = (int)Core::param('point') === -1 ? -1 : 1;
		$cancel = (bool)Core::param('cancel');
		$act = ($point === 1 ? 'procDocumentVoteUp' : 'procDocumentVoteDown') . ($cancel ? 'Cancel' : '');
		if ($cancel && Core::$engine !== 'rhymix')
		{
			throw new ApiError(400, 'not_supported', Auth::lang('msg_invalid_request'));
		}
		self::run($act, array('module' => 'document', 'target_srl' => $oDocument->document_srl));
		// 엔진이 글 정보를 캐시해 두므로 추천 수는 DB 에서 다시 읽는다
		$result = self::forDocument($oDocument);
		$stmt = Core::pdo()->prepare('SELECT voted_count, blamed_count FROM `' . Core::tablePrefix() . 'documents` WHERE document_srl = ?');
		$stmt->execute(array((int)$oDocument->document_srl));
		if ($row = $stmt->fetch())
		{
			$result['vote_up']['count'] = (int)$row['voted_count'];
			$result['vote_down']['count'] = abs((int)$row['blamed_count']);
		}
		return $result;
	}

	/** 추천인 목록: 게시판이 '추천인 공개'로 설정했을 때만 */
	public static function voters()
	{
		$oDocument = self::readableDocument();
		$point = (int)Core::param('point') === -1 ? -1 : 1;
		$config = self::config($oDocument);
		$setting = $point === 1 ? ($config->use_vote_up ?? 'Y') : ($config->use_vote_down ?? 'Y');
		$addon = $point === 1 && $setting !== 'N' && self::voterAddonRuns((int)$oDocument->get('module_srl'));
		if ($setting !== 'S' && !$addon)
		{
			throw new ApiError(403, 'not_public', Auth::lang('msg_not_permitted'));
		}
		$args = new \stdClass;
		$args->document_srl = (int)$oDocument->document_srl;
		if ($point === 1)
		{
			$args->more_point = 0;
		}
		else
		{
			$args->below_point = 0;
		}
		$output = executeQueryArray('document.getVotedMemberList', $args);
		$list = array();
		foreach ((array)$output->data as $row)
		{
			$image = getModel('member')->getProfileImage($row->member_srl);
			// 관리자 설정(추천인 이름 표시): 기본은 닉네임(이름), 닉네임과 이름이 같으면 닉네임만
			$name = Core::displayName($row->nick_name, (int)$row->member_srl, 'voter_name');
			$list[] = array(
				'nick_name' => $name,
				'profile_image' => $image ? Core::absoluteUrl($image->src) : null,
			);
		}
		return array('voters' => $list);
	}

	/** 내 스크랩에 담기 */
	public static function scrap()
	{
		$oDocument = self::readableDocument();
		self::run('procMemberScrapDocument', array('module' => 'member', 'document_srl' => $oDocument->document_srl));
		return array('scrapped' => true);
	}

	/** 신고 */
	public static function report()
	{
		$oDocument = self::readableDocument();
		$reason = mb_substr(trim((string)Core::param('reason')), 0, 500);
		self::run('procDocumentDeclare', array(
			'module' => 'document', 'target_srl' => $oDocument->document_srl,
			'message_option' => $reason !== '' ? 'others' : null, 'declare_message' => $reason !== '' ? $reason : null,
		));
		return array('declared' => true);
	}

	// ---- 내부

	/** 이 게시판의 글이고 지금 회원이 읽을 수 있어야 한다 (비밀글·상담 게시판 포함) */
	private static function readableDocument()
	{
		$mid = (string)Core::param('mid');
		$module_info = preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid) ? getModel('module')->getModuleInfoByMid($mid) : null;
		if (!$module_info || $module_info->module !== 'board' || !Board::canReadBoard($module_info))
		{
			throw new ApiError(404, 'board_not_found', Auth::lang('msg_not_founded'));
		}
		$document_srl = Core::intParam('document_srl');
		$oDocument = $document_srl ? getModel('document')->getDocument($document_srl, false, false) : null;
		if (!$oDocument || !$oDocument->isExists() || (int)$oDocument->get('module_srl') !== (int)$module_info->module_srl)
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		$grant = Board::grant($module_info);
		$granted = $oDocument->isGranted();
		$readable = !empty($grant->view) || $granted;
		if ($readable && ($module_info->consultation ?? '') === 'Y' && !$granted)
		{
			$info = \Context::get('logged_info');
			$readable = $info && (int)$oDocument->get('member_srl') === (int)$info->member_srl;
		}
		if ($readable && $oDocument->isSecret() && !$granted && !$oDocument->isAccessible())
		{
			$readable = false;
		}
		if (!$readable)
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		return $oDocument;
	}

	/** 웹 글 아래에 추천인 목록을 붙이는 애드온 (사이트 운영자가 설치해 쓰는 것) */
	private static $voterAddons = array('colombo_add_vote_list', 'add_vote_list');

	/** 그 애드온이 켜져 있고 이 게시판에서 실행되는가 (엔진의 애드온 실행 규칙: 선택한 게시판 / 선택한 게시판 제외, 목록이 비면 전체) */
	private static function voterAddonRuns($module_srl)
	{
		static $rows = null;
		if ($rows === null)
		{
			$rows = array();
			$in = implode(',', array_fill(0, count(self::$voterAddons), '?'));
			foreach (array('addons_site', 'addons') as $table)
			{
				try
				{
					$where = $table === 'addons_site' ? ' AND site_srl = 0' : '';
					$stmt = Core::pdo()->prepare('SELECT addon, is_used, extra_vars FROM `' . Core::tablePrefix() . $table . "` WHERE addon IN ($in)" . $where);
					$stmt->execute(self::$voterAddons);
					foreach ($stmt->fetchAll() as $row)
					{
						if (!isset($rows[$row['addon']]))
						{
							$rows[$row['addon']] = $row;
						}
					}
				}
				catch (\PDOException $e)
				{
					// 표가 없는 엔진
				}
			}
		}
		$module_info = getModel('module')->getModuleInfoByModuleSrl($module_srl);
		$mid = $module_info ? $module_info->mid : '';
		foreach ($rows as $row)
		{
			if ($row['is_used'] !== 'Y' || !is_dir(\_XE_PATH_ . 'addons/' . $row['addon']))
			{
				continue;
			}
			$vars = @unserialize($row['extra_vars']);
			$mid_list = (is_object($vars) && !empty($vars->mid_list) && is_array($vars->mid_list)) ? $vars->mid_list : array();
			$method = is_object($vars) && !empty($vars->xe_run_method) ? $vars->xe_run_method : 'run_selected';
			$listed = in_array($mid, $mid_list, true);
			if ($method === 'no_run_selected' ? !$listed : ($listed || !$mid_list))
			{
				return true;
			}
		}
		return false;
	}

	private static function config($oDocument)
	{
		$config = getModel('module')->getModulePartConfig('document', (int)$oDocument->get('module_srl'));
		return is_object($config) ? $config : new \stdClass;
	}

	private static function state($setting, $count)
	{
		return array(
			'enabled' => $setting !== 'N',
			'count' => $count,
			// 'S' = 추천인 목록 공개
			'public' => $setting === 'S',
		);
	}

	private static function myVote($document_srl, $member_srl)
	{
		try
		{
			$stmt = Core::pdo()->prepare('SELECT point FROM `' . Core::tablePrefix() . 'document_voted_log` WHERE document_srl = ? AND member_srl = ? ORDER BY regdate DESC LIMIT 1');
			$stmt->execute(array($document_srl, $member_srl));
			$point = (int)$stmt->fetchColumn();
			return $point > 0 ? 1 : ($point < 0 ? -1 : 0);
		}
		catch (\PDOException $e)
		{
			return 0;
		}
	}

	private static function run($act, array $vars)
	{
		try
		{
			return Board::run('', $act, $vars, false);
		}
		catch (ApiError $e)
		{
			// 이미 추천함, 자기 글 등 엔진이 거절한 이유를 그대로 보여 준다
			throw new ApiError(400, 'action_failed', $e->getMessage());
		}
	}
}
