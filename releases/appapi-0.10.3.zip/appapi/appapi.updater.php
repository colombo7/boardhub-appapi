<?php
/**
 * 모듈 스스로 업데이트 (관리자 화면의 [업데이트 확인] → [업데이트]).
 *
 * 1. 공개 저장소의 latest.json 으로 새 버전을 확인한다.
 * 2. zip 을 받아 SHA-256 과 전자서명(conf/release-public.pem, RSA-SHA256)이 맞을 때만 쓴다.
 * 3. 지금 파일을 files/appapi_backup/<버전>-<시각>/ 에 복사해 두고, config.php 는 그대로 둔 채 덮어쓴다.
 *
 * PHP 7.1 호환. 웹 서버가 modules/appapi 폴더에 쓸 수 없으면 업데이트 대신 안내만 한다.
 */
class appapiUpdater
{
	const MANIFEST_URL = 'https://raw.githubusercontent.com/colombo7/boardhub-appapi/main/latest.json';
	const RELEASE_BASE = 'https://raw.githubusercontent.com/colombo7/boardhub-appapi/main/';

	/** 이 폴더 (modules/appapi/) */
	public static function moduleDir()
	{
		return rtrim(str_replace('\\', '/', __DIR__), '/') . '/';
	}

	public static function currentVersion()
	{
		$text = (string)@file_get_contents(self::moduleDir() . 'api.php');
		return preg_match("/define\\('APPAPI_VERSION', '([0-9.]+)'\\)/", $text, $m) ? $m[1] : '0';
	}

	/**
	 * 새 버전 정보. 실패하면 error 에 까닭.
	 * @return array current, latest, notes, has_update, writable, problems(쓸 수 없는 경로), error
	 */
	public static function check()
	{
		$result = array(
			'current' => self::currentVersion(),
			'latest' => null,
			'notes' => '',
			'date' => '',
			'has_update' => false,
			'writable' => false,
			'problems' => self::unwritablePaths(),
			'zip_available' => class_exists('ZipArchive'),
			'error' => null,
		);
		$result['writable'] = !$result['problems'];
		$manifest = self::manifest();
		if (!is_array($manifest))
		{
			$result['error'] = $manifest;
			return $result;
		}
		$result['latest'] = $manifest['version'];
		$result['notes'] = isset($manifest['notes']) ? (string)$manifest['notes'] : '';
		$result['date'] = isset($manifest['date']) ? (string)$manifest['date'] : '';
		$result['has_update'] = version_compare($manifest['version'], $result['current'], '>');
		// 공개된 것보다 새 버전을 직접 올린 경우 (시험·개발판)
		$result['is_newer'] = version_compare($result['current'], $manifest['version'], '>');
		return $result;
	}

	/**
	 * 받아서 확인하고 덮어쓴다.
	 * @return array ok, message, from, to, backup
	 */
	public static function update()
	{
		$from = self::currentVersion();
		$fail = function ($message) use ($from) {
			return array('ok' => false, 'message' => $message, 'from' => $from, 'to' => null, 'backup' => null);
		};
		if (!class_exists('ZipArchive'))
		{
			return $fail('서버 PHP 에 zip 확장(ZipArchive)이 없어 자동 업데이트를 할 수 없습니다. 압축을 풀어 직접 올려 주세요.');
		}
		if ($problems = self::unwritablePaths())
		{
			return $fail('웹 서버가 모듈 폴더에 쓸 수 없습니다: ' . implode(', ', array_slice($problems, 0, 3)));
		}
		$manifest = self::manifest();
		if (!is_array($manifest))
		{
			return $fail($manifest);
		}
		if (!version_compare($manifest['version'], $from, '>'))
		{
			return array('ok' => true, 'message' => '이미 최신 버전입니다.', 'from' => $from, 'to' => $from, 'backup' => null);
		}

		$zip_data = self::fetch(self::RELEASE_BASE . $manifest['zip']);
		if ($zip_data === false || $zip_data === '')
		{
			return $fail('업데이트 파일을 받지 못했습니다.');
		}
		if (!hash_equals(strtolower($manifest['sha256']), hash('sha256', $zip_data)))
		{
			return $fail('받은 파일이 손상되었습니다(SHA-256 불일치).');
		}
		if (!self::verifySignature($zip_data, $manifest['signature']))
		{
			return $fail('전자서명이 맞지 않아 업데이트하지 않았습니다.');
		}

		$tmp = rtrim(sys_get_temp_dir(), '/') . '/appapi-update-' . bin2hex(random_bytes(6));
		@mkdir($tmp, 0700, true);
		$zip_file = $tmp . '/package.zip';
		file_put_contents($zip_file, $zip_data);
		$zip = new ZipArchive();
		if ($zip->open($zip_file) !== true)
		{
			self::removeDir($tmp);
			return $fail('업데이트 파일을 열 수 없습니다.');
		}
		// 묶음 안의 경로는 모두 appapi/ 아래여야 한다 (../ 등 금지)
		for ($i = 0; $i < $zip->numFiles; $i++)
		{
			$name = $zip->getNameIndex($i);
			if (strpos($name, 'appapi/') !== 0 || strpos($name, '..') !== false || strpos($name, "\0") !== false)
			{
				$zip->close();
				self::removeDir($tmp);
				return $fail('업데이트 파일 구성이 올바르지 않습니다.');
			}
		}
		$zip->extractTo($tmp . '/x');
		$zip->close();
		$source = $tmp . '/x/appapi/';
		$new_api = (string)@file_get_contents($source . 'api.php');
		if (!is_file($source . 'conf/info.xml') || strpos($new_api, "define('APPAPI_VERSION', '" . $manifest['version'] . "')") === false)
		{
			self::removeDir($tmp);
			return $fail('업데이트 파일의 버전이 맞지 않습니다.');
		}

		// 지금 파일 백업 (사이트 files 폴더 아래)
		$backup = self::backupDir($from);
		if ($backup === null || !self::copyDir(self::moduleDir(), $backup, array()))
		{
			self::removeDir($tmp);
			return $fail('백업을 만들지 못해 업데이트하지 않았습니다.');
		}

		// 덮어쓰기 (config.php 는 사이트 설정이라 건드리지 않는다)
		if (!self::copyDir($source, self::moduleDir(), array('config.php')))
		{
			self::copyDir($backup, self::moduleDir(), array());
			self::removeDir($tmp);
			return $fail('파일을 쓰다가 실패해 이전 버전으로 되돌렸습니다.');
		}
		self::removeDir($tmp);
		self::resetOpcache(self::moduleDir());
		return array('ok' => true, 'message' => $from . ' → ' . $manifest['version'] . ' 업데이트를 마쳤습니다.', 'from' => $from, 'to' => $manifest['version'], 'backup' => $backup);
	}

	/** latest.json 을 읽어 검사한 배열, 실패하면 까닭 문자열 */
	private static function manifest()
	{
		$text = self::fetch(self::MANIFEST_URL . '?t=' . time());
		if ($text === false || $text === '')
		{
			return '업데이트 정보를 받지 못했습니다. 서버에서 github 로 나가는 연결을 확인해 주세요.';
		}
		$manifest = json_decode($text, true);
		if (!is_array($manifest) || empty($manifest['version']) || empty($manifest['zip']) || empty($manifest['sha256']) || empty($manifest['signature'])
			|| !preg_match('/^[0-9]+(\.[0-9]+){1,3}$/', $manifest['version']) || !preg_match('#^releases/appapi-[0-9.]+\.zip$#', $manifest['zip']))
		{
			return '업데이트 정보 형식이 올바르지 않습니다.';
		}
		if (!empty($manifest['min_php']) && version_compare(PHP_VERSION, $manifest['min_php'], '<'))
		{
			return '새 버전은 PHP ' . $manifest['min_php'] . ' 이상이 필요합니다 (이 서버 ' . PHP_VERSION . ').';
		}
		return $manifest;
	}

	private static function verifySignature($data, $signature_base64)
	{
		$public = @file_get_contents(self::moduleDir() . 'conf/release-public.pem');
		$signature = base64_decode((string)$signature_base64, true);
		if (!$public || $signature === false || !function_exists('openssl_verify'))
		{
			return false;
		}
		return openssl_verify($data, $signature, $public, OPENSSL_ALGO_SHA256) === 1;
	}

	/**
	 * 서버에서 github 로 나가는 연결이 가끔 끊기거나(주소 찾기 지연) 느린 곳이 있어 세 번까지 다시 해 본다 (kgpa: 8번 중 1번 실패).
	 */
	private static function fetch($url)
	{
		for ($try = 1; $try <= 3; $try++)
		{
			$body = self::fetchOnce($url);
			if ($body !== false)
			{
				return $body;
			}
			if ($try < 3)
			{
				sleep(1);
			}
		}
		return false;
	}

	private static function fetchOnce($url)
	{
		if (function_exists('curl_init'))
		{
			$ch = curl_init($url);
			curl_setopt_array($ch, array(
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_CONNECTTIMEOUT => 15,
				CURLOPT_TIMEOUT => 60,
				// IPv6 로는 github 에 닿지 않는 서버가 있어, IPv6 를 먼저 시도하느라 기다리지 않게
				CURLOPT_IPRESOLVE => CURL_IPRESOLVE_V4,
				CURLOPT_USERAGENT => 'BoardHub-appapi-updater',
			));
			$body = curl_exec($ch);
			$status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);
			return ($body !== false && $status === 200) ? $body : false;
		}
		$context = stream_context_create(array('http' => array('timeout' => 60, 'user_agent' => 'BoardHub-appapi-updater')));
		return @file_get_contents($url, false, $context);
	}

	/** 웹 서버가 쓸 수 없는 파일·폴더 (모듈 폴더 기준 상대 경로) */
	private static function unwritablePaths()
	{
		$base = self::moduleDir();
		$problems = array();
		if (!is_writable($base))
		{
			$problems[] = 'modules/appapi/';
		}
		$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
		foreach ($iterator as $path => $info)
		{
			if (!is_writable($path))
			{
				$problems[] = 'modules/appapi/' . substr(str_replace('\\', '/', $path), strlen($base));
			}
		}
		return $problems;
	}

	private static function backupDir($version)
	{
		$root = defined('RX_BASEDIR') ? RX_BASEDIR : _XE_PATH_;
		$dir = rtrim($root, '/') . '/files/appapi_backup/' . preg_replace('/[^0-9.]/', '', $version) . '-' . date('YmdHis') . '/';
		return @mkdir($dir, 0755, true) ? $dir : null;
	}

	private static function copyDir($from, $to, array $skip)
	{
		$from = rtrim($from, '/') . '/';
		$to = rtrim($to, '/') . '/';
		$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
		foreach ($iterator as $path => $info)
		{
			$relative = substr(str_replace('\\', '/', $path), strlen($from));
			if (in_array($relative, $skip, true) || basename($relative) === '.DS_Store' || strpos(basename($relative), '._') === 0)
			{
				continue;
			}
			if ($info->isDir())
			{
				if (!is_dir($to . $relative) && !@mkdir($to . $relative, 0755, true))
				{
					return false;
				}
			}
			elseif (!@copy($path, $to . $relative))
			{
				return false;
			}
		}
		return true;
	}

	private static function removeDir($dir)
	{
		if (!is_dir($dir))
		{
			return;
		}
		$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
		foreach ($iterator as $path => $info)
		{
			$info->isDir() ? @rmdir($path) : @unlink($path);
		}
		@rmdir($dir);
	}

	/** 새 파일이 바로 쓰이도록 opcache 에서 이 모듈 파일을 지운다 */
	private static function resetOpcache($dir)
	{
		if (!function_exists('opcache_invalidate'))
		{
			return;
		}
		$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
		foreach ($iterator as $path => $info)
		{
			if (substr($path, -4) === '.php')
			{
				@opcache_invalidate($path, true);
			}
		}
	}
}
