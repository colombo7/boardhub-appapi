<?php
/**
 * 앱 연동 설정 화면
 */
class appapiAdminView extends appapi
{
	function init()
	{
		$this->setTemplatePath($this->module_path . 'tpl');
	}

	function dispAppapiAdminConfig()
	{
		$config = getModel('module')->getModuleConfig('appapi');
		if (!is_object($config))
		{
			$config = new stdClass;
		}
		$styles = (isset($config->board_styles) && is_array($config->board_styles)) ? $config->board_styles : array();

		$args = new stdClass;
		$args->module = 'board';
		$boards = array();
		foreach ((array)getModel('module')->getMidList($args) as $board)
		{
			$boards[] = (object)array(
				'mid' => htmlspecialchars($board->mid, ENT_QUOTES, 'UTF-8'),
				'title' => htmlspecialchars($board->browser_title, ENT_QUOTES, 'UTF-8'),
				'style' => isset($styles[$board->mid]) ? $styles[$board->mid] : '',
			);
		}

		$view = new stdClass;
		foreach (array('site_name', 'theme_color', 'logo_url', 'icon_url', 'api_port', 'voter_name', 'author_name') as $key)
		{
			$view->$key = htmlspecialchars(isset($config->$key) ? (string)$config->$key : '', ENT_QUOTES, 'UTF-8');
		}
		Context::set('appapi_config', $view);
		Context::set('appapi_boards', $boards);
		Context::set('appapi_url', htmlspecialchars(Context::getDefaultUrl() . 'modules/appapi/api.php?r=site', ENT_QUOTES, 'UTF-8'));
		Context::set('appapi_engine', defined('RX_VERSION') ? 'Rhymix ' . RX_VERSION : 'XE ' . __XE_VERSION__);

		// 모듈 업데이트: [업데이트 확인]을 눌렀을 때만 밖(github)에 묻는다
		require_once __DIR__ . '/appapi.updater.php';
		Context::set('appapi_version', appapiUpdater::currentVersion());
		$update = Context::get('check_update') ? appapiUpdater::check() : null;
		if ($update)
		{
			foreach (array('notes', 'error', 'latest', 'date') as $key)
			{
				$update[$key] = htmlspecialchars((string)$update[$key], ENT_QUOTES, 'UTF-8');
			}
			$update['problems'] = array_map(function ($path) { return htmlspecialchars($path, ENT_QUOTES, 'UTF-8'); }, $update['problems']);
		}
		Context::set('appapi_update', $update ? (object)$update : null);
		$result = isset($_SESSION['appapi_update_result']) ? $_SESSION['appapi_update_result'] : null;
		unset($_SESSION['appapi_update_result']);
		if ($result)
		{
			$result['message'] = htmlspecialchars((string)$result['message'], ENT_QUOTES, 'UTF-8');
			$result['backup'] = htmlspecialchars((string)$result['backup'], ENT_QUOTES, 'UTF-8');
		}
		Context::set('appapi_update_result', $result ? (object)$result : null);
		$this->setTemplateFile('config');
	}
}
