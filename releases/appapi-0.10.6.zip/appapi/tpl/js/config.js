/* 관리 화면: 앱이 이 사이트에 접속할 수 있는지 스스로 확인해 결과만 보여 준다 */
(function () {
	var box = document.getElementById('appapi-status');
	if (!box) return;
	var text = box.querySelector('.appapi-status-text');
	function show(ok, message) {
		text.innerHTML = '';
		var mark = document.createElement('strong');
		mark.style.color = ok ? '#1a7f37' : '#cf222e';
		mark.textContent = ok ? '✓ 정상' : '✗ 접속 안 됨';
		text.appendChild(mark);
		text.appendChild(document.createTextNode(' — ' + message));
		if (!ok) {
			var link = document.createElement('a');
			link.href = box.getAttribute('data-link');
			link.target = '_blank';
			link.textContent = '직접 열어 보기';
			text.appendChild(document.createTextNode(' '));
			text.appendChild(link);
		}
	}
	var xhr = new XMLHttpRequest();
	xhr.open('GET', box.getAttribute('data-url'), true);
	xhr.timeout = 15000;
	xhr.onload = function () {
		var data = null;
		try { data = JSON.parse(xhr.responseText); } catch (e) {}
		if (data && data.ok) {
			var d = data.data || {};
			show(true, '앱에서 이 사이트를 추가할 수 있습니다' + (d.api_version ? ' (모듈 ' + d.api_version + ')' : ''));
		} else if (data && data.error) {
			show(false, data.error.message || data.error.code || '응답 오류');
		} else {
			show(false, '응답이 앱 형식이 아닙니다 (HTTP ' + xhr.status + ')');
		}
	};
	xhr.onerror = function () { show(false, '서버에 접속하지 못했습니다'); };
	xhr.ontimeout = function () { show(false, '응답이 너무 늦습니다'); };
	xhr.send();
})();
