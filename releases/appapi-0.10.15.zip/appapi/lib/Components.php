<?php
namespace AppApi;

/**
 * 사이트 스크립트가 있어야 보이는 편집기 부품을 앱용 보통 HTML 로 (앱이 with_media=1 을 보낼 때만, 예전 앱은 그대로).
 *
 * - multimedia_link: 웹은 mp3·mp4 말고는 <script>displayMultimedia(…)</script> 를 내고 사이트 JS 가 플레이어를 그린다.
 *   앱에는 그 JS 가 없어 빈칸이 되므로, 주소를 보고 유튜브·비메오는 퍼가기 iframe, 영상·소리 파일은 <video>·<audio>,
 *   나머지(플래시·wmv 등)는 링크로 바꾼다.
 * - image_gallery: 웹은 갤러리 스크립트(xe.getApp)가 그림을 그린다. 엔진이 XMLRPC 응답에서 하듯 그림 목록(<img>)으로 바꾼다.
 * 본문은 엔진이 부품을 바꾸기 전(getContent)의 것을 받아, 이 두 부품만 먼저 바꾼다(나머지 부품은 엔진이 웹과 같이 바꾼다).
 */
class Components
{
	public static function replace($content)
	{
		$content = (string)$content;
		if (stripos($content, 'multimedia_link') === false && stripos($content, 'image_gallery') === false)
		{
			return $content;
		}
		return preg_replace_callback(Polls::COMPONENT, function ($m) {
			$attrs = self::attrs($m);
			switch ($attrs['editor_component'] ?? '')
			{
				case 'multimedia_link':
					return self::multimedia($attrs, isset($m[4]) ? $m[4] : '');
				case 'image_gallery':
					return self::gallery($attrs);
				default:
					return $m[0];
			}
		}, $content);
	}

	/** 부품의 속성 (엔진 editorController::transEditorComponent 와 같은 방식으로 읽는다) */
	private static function attrs($m)
	{
		$script = ' ' . $m[2] . ' editor_component=' . $m[3];
		$script = preg_replace('/([\w:-]+)\s*=(?:\s*(["\']))?((?(2).*?|[^ ]+))\2/i', '\1="\3"', $script);
		preg_match_all('/([a-z0-9_-]+)="([^"]+)"/is', $script, $mm);
		$attrs = array();
		foreach ($mm[1] as $i => $name)
		{
			$attrs[strtolower($name)] = $mm[2][$i];
		}
		return $attrs;
	}

	private static function multimedia(array $attrs, $caption)
	{
		$src = trim(html_entity_decode((string)($attrs['multimedia_src'] ?? ''), ENT_QUOTES, 'UTF-8'));
		if ($src === '' || preg_match('#^\s*(javascript|vbscript|data):#i', $src))
		{
			return '';
		}
		preg_match_all('/(width|height)([^[:digit:]]+)([0-9]+)/i', (string)($attrs['style'] ?? ''), $size);
		$width = (int)($size[3][0] ?? 0) ?: 480;
		$height = (int)($size[3][1] ?? 0) ?: 360;
		$url = Core::absoluteUrl($src);
		$e = function ($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); };
		$path = strtolower((string)parse_url($url, PHP_URL_PATH));

		if ($id = self::youtubeId($url))
		{
			return sprintf('<iframe src="https://www.youtube.com/embed/%s" width="%d" height="%d" frameborder="0" allowfullscreen="allowfullscreen"></iframe>', $e($id), $width, $height);
		}
		if (preg_match('#^https?://(?:www\.|player\.)?vimeo\.com/(?:video/)?(\d+)#i', $url, $v))
		{
			return sprintf('<iframe src="https://player.vimeo.com/video/%s" width="%d" height="%d" frameborder="0" allowfullscreen="allowfullscreen"></iframe>', $v[1], $width, $height);
		}
		if (preg_match('/\.(mp4|m4v|mov|webm|ogv)$/', $path))
		{
			return sprintf('<video controls="controls" preload="none" width="%d" height="%d" src="%s"></video>', $width, $height, $e($url));
		}
		if (preg_match('/\.(mp3|m4a|aac|ogg|oga|wav)$/', $path))
		{
			return sprintf('<audio controls="controls" preload="none" src="%s"></audio>', $e($url));
		}
		// 앱에서 틀 수 없는 형식(플래시·wmv·asf 등): 링크로 (누르면 앱 안 브라우저)
		$label = trim(strip_tags((string)$caption));
		if ($label === '')
		{
			$label = basename((string)parse_url($url, PHP_URL_PATH)) ?: $url;
		}
		return sprintf('<a href="%s">▶ %s</a>', $e($url), $e($label));
	}

	private static function youtubeId($url)
	{
		if (preg_match('#^https?://(?:www\.|m\.)?youtube(?:-nocookie)?\.com/(?:watch\?(?:.*&)?v=|embed/|v/|shorts/)([A-Za-z0-9_-]{6,20})#i', $url, $m)
			|| preg_match('#^https?://youtu\.be/([A-Za-z0-9_-]{6,20})#i', $url, $m))
		{
			return $m[1];
		}
		return null;
	}

	/** 엔진 image_gallery::transHTML 과 같은 규칙으로 그림 목록을 읽어 <img> 로 */
	private static function gallery(array $attrs)
	{
		$list = trim(preg_replace('/\.(gif|jpe?g|png) /i', ".\\1\n", (string)($attrs['images_list'] ?? '')));
		$images = preg_grep('/^[a-z0-9\/]+\.(gif|jpe?g|png)+$/i', explode("\n", $list));
		// 부품은 보통 <p> 안에 있으므로 블록 태그 없이 줄바꿈으로 잇는다
		$html = array();
		foreach (array_values($images) as $i => $src)
		{
			$html[] = sprintf('<img src="%s" alt="Gallery image no.%d" style="max-width:100%%;height:auto;" />', htmlspecialchars(Core::absoluteUrl(trim($src)), ENT_QUOTES, 'UTF-8'), $i + 1);
		}
		return implode('<br />', $html);
	}
}
