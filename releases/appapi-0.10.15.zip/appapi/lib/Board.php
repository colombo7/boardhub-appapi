<?php
namespace AppApi;

/**
 * 게시판: 목록·본문·댓글·첨부.
 *
 * 게시판 모듈을 웹과 똑같이 실행하되(ModuleHandler::init → procModule) 스킨·레이아웃 렌더링은 하지 않고,
 * 모듈이 Context 에 채운 값(document_list, oDocument, ...)을 JSON 으로 바꾼다.
 * 비밀글·상담글·그룹 권한·읽기 포인트 같은 규칙은 각 엔진의 게시판 코드가 그대로 처리한다.
 */
class Board
{
	public static function documents()
	{
		$mid = self::mid();
		$oModule = self::run($mid, 'dispBoardContent', array(
			'page' => max(1, Core::intParam('page', 1)),
			'category' => Core::intParam('category', 0) ?: null,
			'search_target' => self::searchTarget(),
			'search_keyword' => Core::param('search_keyword') !== null ? mb_substr(trim((string)Core::param('search_keyword')), 0, 100) : null,
			// 작성글 보기 (Rhymix 게시판은 member_srl 로 그 회원의 글만 거른다)
			'member_srl' => Core::intParam('member_srl') ?: null,
		));

		$documents = array();
		foreach ((array)\Context::get('document_list') as $oDocument)
		{
			$documents[] = self::documentSummary($oDocument);
		}
		$notices = array();
		foreach ((array)\Context::get('notice_list') as $oDocument)
		{
			$notices[] = self::documentSummary($oDocument);
		}

		$nav = \Context::get('page_navigation');
		return array(
			'board' => self::boardInfo($oModule),
			'notices' => $notices,
			'documents' => $documents,
			'page' => (int)($nav ? $nav->cur_page : 1),
			'total_pages' => (int)($nav ? $nav->total_page : 1),
			'total_count' => (int)\Context::get('total_count'),
		);
	}

	/**
	 * 여러 게시판의 새 글 모아 보기 (앱 홈 화면).
	 * mids 를 주지 않으면 메뉴에 있는 게시판 중 목록·읽기 권한이 있는 곳 전부.
	 */
	public static function feed()
	{
		$mids = array_filter(explode(',', (string)Core::param('mids', '')), function ($mid) {
			return preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid);
		});
		if (!$mids)
		{
			$mids = Menu::boardMids();
		}

		$boards = array();
		foreach (array_slice(array_unique($mids), 0, 100) as $mid)
		{
			$module_info = getModel('module')->getModuleInfoByMid($mid);
			if ($module_info && $module_info->module === 'board' && self::canReadBoard($module_info, true))
			{
				$boards[(int)$module_info->module_srl] = $module_info;
			}
		}
		if (!$boards)
		{
			return array('documents' => array(), 'page' => 1, 'total_pages' => 1);
		}

		// 여러 게시판을 한 번에: XE 의 getDocumentList 는 게시판 여러 개를 주면 첫 게시판 글만 돌려주는 경우가 있어
		// 글 번호는 직접 고르고(읽을 수 있는 게시판만), 글 내용은 엔진으로 불러온다.
		$oDocumentModel = getModel('document');
		$page = max(1, Core::intParam('page', 1));
		$list_count = min(50, max(5, Core::intParam('list_count', 20)));
		$module_srls = array_map('intval', array_keys($boards));
		$statuses = array($oDocumentModel->getConfigStatus('public'), $oDocumentModel->getConfigStatus('secret'));
		$in_modules = implode(',', array_fill(0, count($module_srls), '?'));
		$in_status = implode(',', array_fill(0, count($statuses), '?'));
		$table = '`' . Core::tablePrefix() . 'documents`';
		$params = array_merge($module_srls, $statuses);
		$stmt = Core::pdo()->prepare("SELECT COUNT(*) FROM $table WHERE module_srl IN ($in_modules) AND status IN ($in_status)");
		$stmt->execute($params);
		$total = (int)$stmt->fetchColumn();
		$stmt = Core::pdo()->prepare("SELECT document_srl FROM $table WHERE module_srl IN ($in_modules) AND status IN ($in_status) ORDER BY list_order ASC LIMIT " . (($page - 1) * $list_count) . ', ' . $list_count);
		$stmt->execute($params);
		$srls = array_map('intval', $stmt->fetchAll(\PDO::FETCH_COLUMN));
		$loaded = $srls ? $oDocumentModel->getDocuments($srls, false, false) : array();
		$output = new \stdClass;
		$output->data = array();
		foreach ($srls as $srl)
		{
			if (isset($loaded[$srl]) && $loaded[$srl]->isExists())
			{
				$output->data[] = $loaded[$srl];
			}
		}
		$total_pages = max(1, (int)ceil($total / $list_count));

		$documents = array();
		foreach ((array)$output->data as $oDocument)
		{
			$board = $boards[(int)$oDocument->get('module_srl')];
			$item = self::documentSummary($oDocument);
			$item['mid'] = $board->mid;
			$item['board_title'] = $board->browser_title;
			$documents[] = $item;
		}
		return array(
			'documents' => $documents,
			'page' => $page,
			'total_pages' => $total_pages,
		);
	}

	/**
	 * 현재 회원의 모듈 권한 (엔진의 getGrant: 그룹·관리자·사이트 설정 반영).
	 */
	public static function grant($module_info)
	{
		static $cache = array();
		$key = (int)$module_info->module_srl;
		if (!isset($cache[$key]))
		{
			$logged_info = \Context::get('logged_info') ?: new \stdClass;
			$cache[$key] = getModel('module')->getGrant($module_info, $logged_info);
		}
		return $cache[$key];
	}

	/**
	 * 이 회원에게 보여도 되는 모듈인가. 읽기(목록) 권한이 없는 게시판은 메뉴·링크 어디에도 나오지 않는다.
	 * 페이지는 접근 권한, 그 밖의 모듈은 메뉴에 둔 그대로 둔다.
	 */
	public static function isVisible($module_info)
	{
		if ($module_info->module === 'board')
		{
			return self::canReadBoard($module_info);
		}
		if (!self::grant($module_info)->access)
		{
			return false;
		}
		return !($module_info->module === 'page' && self::pageShowsOnlyRestricted($module_info));
	}

	/**
	 * 위젯 페이지가 보여 주는 게시판(위젯의 module_srls)이 모두 이 회원에게 권한 밖이면 true.
	 * 이런 페이지는 내용이 권한 없는 게시판의 글 목록뿐이라 메뉴에서 숨긴다.
	 */
	public static function pageShowsOnlyRestricted($module_info)
	{
		$content = (string)($module_info->content ?? '');
		if (!preg_match_all('/module_srls="([^"]*)"/', $content, $matches))
		{
			return false;
		}
		$srls = array();
		foreach ($matches[1] as $value)
		{
			foreach (explode(',', urldecode($value)) as $srl)
			{
				if (ctype_digit(trim($srl)))
				{
					$srls[(int)$srl] = true;
				}
			}
		}
		if (!$srls)
		{
			return false;
		}
		foreach (array_keys($srls) as $srl)
		{
			$info = getModel('module')->getModuleInfoByModuleSrl($srl);
			if ($info && self::isVisible($info))
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * 현재 회원이 이 게시판의 목록을 볼 수 있는지.
	 * $for_feed 이면 글 읽기 권한까지 있고 상담 게시판이 아니어야 한다.
	 */
	public static function canReadBoard($module_info, $for_feed = false)
	{
		$grant = self::grant($module_info);
		if (!$grant->access || !$grant->list)
		{
			return false;
		}
		// 목록 권한만 있고 열람 권한이 없는 게시판도 새 글 모아 보기에 넣는다 (게시판 목록과 같이 제목까지, 요약·사진은 documentSummary 가 뺀다)
		if ($for_feed)
		{
			if (($module_info->consultation ?? '') === 'Y' && !$grant->manager && empty($grant->consultation_read))
			{
				return false;
			}
		}
		return true;
	}

	public static function document()
	{
		$mid = self::mid();
		$document_srl = Core::intParam('document_srl');
		if (!$document_srl)
		{
			throw new ApiError(400, 'missing_document_srl', 'document_srl is required');
		}
		// 조회수: 이 앱 접속에서 이미 읽은 글이면 엔진이 다시 세지 않게 (사이트의 조회수 설정은 엔진이 따른다)
		Views::before($document_srl);
		$oModule = self::run($mid, 'dispBoardContent', array('document_srl' => $document_srl, 'cpage' => max(1, Core::intParam('cpage', 1))));

		$oDocument = \Context::get('oDocument');
		if (!$oDocument || !$oDocument->isExists() || (int)$oDocument->document_srl !== $document_srl)
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		if (!self::canRead($oModule, $oDocument))
		{
			throw new ApiError(403, 'not_permitted', Auth::lang('msg_not_permitted'));
		}
		Views::after($document_srl);
		self::markNotificationsRead($oModule);

		$data = self::documentSummary($oDocument);
		$accessible = !$oDocument->isSecret() || $oDocument->isGranted() || $oDocument->isAccessible();
		// with_polls=1(새 앱): 글 속 설문을 자리표시로 두고 데이터로 준다. 없으면 예전과 똑같이 엔진이 그린 설문 HTML 그대로
		// with_media=1(새 앱): 사이트 스크립트가 있어야 보이는 편집기 부품(멀티미디어·이미지 갤러리)을 보통 HTML(영상·그림)로
		$poll_ids = array();
		if ($accessible && (Core::param('with_polls') || Core::param('with_media')))
		{
			// getTransContent 와 같은 순서(getContent → 편집기 부품 바꾸기) 사이에서 해당 부품만 먼저 바꾼다
			$content = $oDocument->getContent(false, false, true, false);
			if (Core::param('with_polls'))
			{
				$content = Polls::replaceComponents($content, $poll_ids);
			}
			if (Core::param('with_media'))
			{
				$content = Components::replace($content);
			}
			$data['content_html'] = Core::absolutizeHtml(getController('editor')->transComponent($content));
		}
		else
		{
			$data['content_html'] = $accessible ? Core::absolutizeHtml($oDocument->getTransContent(false, false, true, false)) : null;
		}
		$data['files'] = $accessible ? self::files($oDocument->getUploadedFiles(), $mid) : array();
		// 비밀글을 볼 수 없으면 확장 변수(전화·주소 같은 추가 항목)도 주지 않는다 (웹도 본문과 함께 가린다)
		$data['extra_vars'] = $accessible ? self::extraVars($oDocument) : array();
		$data['permanent_url'] = $oDocument->getPermanentUrl();
		$data['can_comment'] = (bool)($oDocument->allowComment() && $oModule->grant->write_comment);
		// 작성자 본인이거나 관리 권한: 삭제 경로도 같은 판단으로 막는다
		$data['can_edit'] = (bool)$oDocument->isGranted();
		$data['can_delete'] = (bool)$oDocument->isGranted();
		$data['board'] = self::boardInfo($oModule);
		$data['actions'] = Actions::forDocument($oDocument);
		$data['comments'] = self::commentPage($oDocument, $mid);
		if (Core::param('with_polls'))
		{
			$data['polls'] = Polls::infos($poll_ids);
		}
		return $data;
	}

	public static function comments()
	{
		$mid = self::mid();
		$document_srl = Core::intParam('document_srl');
		// 댓글 쪽만 넘겨도 엔진은 글 보기를 거치므로, 글을 연 것과 같이 처리한다 (같은 접속이면 다시 세지 않는다)
		Views::before($document_srl);
		$oModule = self::run($mid, 'dispBoardContent', array('document_srl' => $document_srl, 'cpage' => max(1, Core::intParam('cpage', 1))));
		$oDocument = \Context::get('oDocument');
		if (!$oDocument || !$oDocument->isExists() || !self::canRead($oModule, $oDocument))
		{
			throw new ApiError(404, 'document_not_found', Auth::lang('msg_not_founded'));
		}
		Views::after($document_srl);
		return self::commentPage($oDocument, $mid);
	}

	/**
	 * 본문 속 사이트 내부 링크를 앱 화면으로 옮기기 위한 조회: 글 번호만 있는 링크의 게시판, mid 의 모듈 종류.
	 * 게시판 이름만 알려 주고, 글 내용·권한 판단은 하지 않는다 (실제 열람은 document 에서 권한 검사).
	 */
	public static function resolve()
	{
		$mid = (string)Core::param('mid', '');
		if ($mid !== '' && !preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid))
		{
			throw new ApiError(400, 'invalid_mid', 'invalid mid');
		}
		$document_srl = Core::intParam('document_srl');
		if ($document_srl && $mid === '')
		{
			$oDocument = getModel('document')->getDocument($document_srl, false, false);
			if ($oDocument && $oDocument->isExists())
			{
				$module_info = getModel('module')->getModuleInfoByModuleSrl((int)$oDocument->get('module_srl'));
				$mid = $module_info ? (string)$module_info->mid : '';
			}
		}
		$module_info = $mid !== '' ? getModel('module')->getModuleInfoByMid($mid) : null;
		// 권한 없는 게시판은 있다는 사실도 알리지 않는다
		if (!$module_info || !self::isVisible($module_info))
		{
			throw new ApiError(404, 'not_found', Auth::lang('msg_not_founded'));
		}
		return array(
			'mid' => $module_info->mid,
			'module' => $module_info->module,
			'title' => $module_info->browser_title,
			'document_srl' => $document_srl ?: null,
		);
	}

	/**
	 * 페이지 모듈(소개·안내 등). 위젯형 페이지는 사이트 CSS 가 필요할 수 있어 웹 주소도 함께 준다.
	 */
	public static function page()
	{
		$mid = self::mid();
		$module_info = getModel('module')->getModuleInfoByMid($mid);
		if (!$module_info || $module_info->module !== 'page')
		{
			throw new ApiError(400, 'not_page', 'not a page');
		}
		// 메뉴에서 숨긴 페이지(권한 없는 게시판 목록뿐인 페이지 등)는 직접 열어도 없는 것처럼
		if (!self::isVisible($module_info))
		{
			throw new ApiError(404, 'not_found', Auth::lang('msg_not_founded'));
		}
		$oModule = self::run($mid, 'dispPageIndex', array(), false);
		// 웹에서는 화면 출력 단계에서 위젯 자리표시를 실제 HTML 로 바꾼다. 그 단계를 건너뛰므로 직접 바꾼다.
		$html = getController('widget')->transWidgetCode((string)\Context::get('page_content'));
		$html = self::removeRestrictedLinks($html);
		return array(
			'mid' => $mid,
			'title' => $oModule->module_info->browser_title,
			'page_type' => strtolower((string)$oModule->module_info->page_type),
			'content_html' => Core::absolutizeHtml($html),
			'web_url' => Core::$base_url . $mid,
		);
	}

	/**
	 * 페이지(위젯) 속에서 이 회원이 읽을 수 없는 게시판·글로 가는 링크를 그 줄(li/tr)째 지운다.
	 * 최신글 위젯 등이 권한 없는 게시판의 글 제목을 보여 주는 것을 막는다.
	 */
	public static function removeRestrictedLinks($html)
	{
		if (trim($html) === '' || stripos($html, '<a') === false || !class_exists('DOMDocument'))
		{
			return $html;
		}
		$dom = new \DOMDocument();
		$previous = libxml_use_internal_errors(true);
		$dom->loadHTML('<?xml encoding="utf-8"?><div id="appapi-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
		libxml_clear_errors();
		libxml_use_internal_errors($previous);

		$remove = array();
		foreach (iterator_to_array($dom->getElementsByTagName('a')) as $a)
		{
			$mid = self::linkedMid($a->getAttribute('href'));
			if ($mid === null)
			{
				continue;
			}
			$module_info = getModel('module')->getModuleInfoByMid($mid);
			if ($module_info && self::isVisible($module_info))
			{
				continue;
			}
			// 목록의 한 줄이면 줄째, 아니면 링크만
			$target = $a;
			for ($node = $a->parentNode; $node && $node->nodeName !== 'div'; $node = $node->parentNode)
			{
				if (in_array(strtolower($node->nodeName), array('li', 'tr', 'dt', 'dd'), true))
				{
					$target = $node;
					break;
				}
			}
			$remove[] = $target;
		}
		if (!$remove)
		{
			return $html;
		}
		foreach ($remove as $node)
		{
			if ($node->parentNode)
			{
				$node->parentNode->removeChild($node);
			}
		}
		$root = $dom->getElementById('appapi-root') ?: $dom->getElementsByTagName('div')->item(0);
		$out = '';
		foreach ($root->childNodes as $child)
		{
			$out .= $dom->saveHTML($child);
		}
		return $out;
	}

	/**
	 * 같은 사이트 링크가 가리키는 게시판 mid (/mid, /mid/123, /123, ?mid=, ?document_srl=). 다른 사이트·판단 불가면 null.
	 */
	private static function linkedMid($href)
	{
		$parts = parse_url(Core::absoluteUrl(html_entity_decode((string)$href, ENT_QUOTES, 'UTF-8')));
		$site_host = preg_replace('/^www\./', '', strtolower((string)parse_url(Core::$base_url, PHP_URL_HOST)));
		if (empty($parts['host']) || preg_replace('/^www\./', '', strtolower($parts['host'])) !== $site_host)
		{
			return null;
		}
		$query = array();
		if (!empty($parts['query']))
		{
			parse_str($parts['query'], $query);
		}
		$mid = (isset($query['mid']) && is_string($query['mid'])) ? $query['mid'] : null;
		$document_srl = isset($query['document_srl']) ? (int)$query['document_srl'] : 0;
		$path = trim((string)($parts['path'] ?? ''), '/');
		$path = preg_replace('#(^|/)index\.php$#', '', $path);
		if ($mid === null && !$document_srl && $path !== '')
		{
			$segments = explode('/', $path);
			if (count($segments) === 1)
			{
				if (ctype_digit($segments[0])) { $document_srl = (int)$segments[0]; } else { $mid = $segments[0]; }
			}
			elseif (count($segments) === 2)
			{
				$mid = $segments[0];
			}
		}
		if ($mid === null && $document_srl)
		{
			$stmt = Core::pdo()->prepare('SELECT m.mid FROM `' . Core::tablePrefix() . 'documents` d JOIN `' . Core::tablePrefix() . 'modules` m ON m.module_srl = d.module_srl WHERE d.document_srl = ?');
			$stmt->execute(array($document_srl));
			$mid = $stmt->fetchColumn() ?: null;
		}
		return ($mid !== null && preg_match('/^[a-zA-Z][a-zA-Z0-9_]*$/', $mid)) ? $mid : null;
	}

	/**
	 * 첨부 다운로드: 웹과 같은 procFileDownload 를 실행한다 (권한·다운로드 포인트 포함).
	 */
	public static function file()
	{
		$file_srl = Core::intParam('file_srl');
		$sid = preg_replace('/[^a-zA-Z0-9]/', '', (string)Core::param('sid'));
		if (!$file_srl || $sid === '')
		{
			throw new ApiError(400, 'missing_file', 'file_srl and sid are required');
		}
		while (ob_get_level() > 0)
		{
			ob_end_clean();
		}
		// 엔진이 파일 주소로 넘기고(302) 끝낸다. 끝날 때 JSON 오류로 바꾸지 않게
		Response::$passthrough = true;
		$oModule = self::run('', 'procFileDownload', array('module' => 'file', 'file_srl' => $file_srl, 'sid' => $sid), false);
		// 여기까지 왔다면 파일을 내보내지 못한 것이다.
		$message = ($oModule && method_exists($oModule, 'getMessage')) ? $oModule->getMessage() : 'msg_not_permitted';
		throw new ApiError(403, 'download_failed', Auth::lang($message));
	}

	// ------------------------------------------------------------------

	private static function mid()
	{
		$mid = (string)Core::param('mid');
		if (!preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', $mid))
		{
			throw new ApiError(400, 'invalid_mid', 'invalid mid');
		}
		return $mid;
	}

	private static function searchTarget()
	{
		$target = (string)Core::param('search_target');
		return in_array($target, array('title', 'content', 'title_content', 'comment', 'nick_name', 'user_id', 'tag'), true) ? $target : null;
	}

	/**
	 * 모듈 액션을 웹 요청과 같은 경로로 실행하고 모듈 객체를 돌려준다.
	 */
	public static function run($mid, $act, array $vars, $expect_board = true, $as_json = false)
	{
		$document_srl = isset($vars['document_srl']) ? $vars['document_srl'] : '';
		$module = isset($vars['module']) ? $vars['module'] : '';
		$vars['mid'] = $mid;
		$vars['act'] = $act;
		// 앱이 푼 CAPTCHA 답(captcha_response): 웹 양식과 같은 이름으로 넘긴다. 확인(구글·Cloudflare 에 묻기)은 엔진의 CAPTCHA 트리거가 한다
		$captcha_response = self::captchaResponse();
		if ($captcha_response !== '' && strpos($act, 'proc') === 0 && !isset($vars['g-recaptcha-response']))
		{
			$vars['g-recaptcha-response'] = $captcha_response;
		}
		foreach ($vars as $key => $value)
		{
			if ($value !== null && $value !== '')
			{
				$_GET[$key] = $_REQUEST[$key] = $value;
				\Context::set($key, $value, true);
			}
		}
		if ($act !== '' && strpos($act, 'proc') === 0 && !in_array($act, self::$getProcs, true))
		{
			// 엔진이 기억한 요청 방식도 POST 로: GET 으로 남아 있으면 쓰기 뒤 보기 화면으로 넘어가고 CSRF 검사도 건너뛴다
			$_SERVER['REQUEST_METHOD'] = 'POST';
			// 웹에서 AJAX 로 부르는 동작(쪽지·친구)은 JSON 방식이어야 알림창 HTML 을 찍고 끝내지 않는다
			\Context::setRequestMethod($as_json ? 'JSON' : 'POST');
			self::prepareWriteRequest();
		}

		if ($mid !== '')
		{
			$module_info = getModel('module')->getModuleInfoByMid($mid);
			if (!$module_info)
			{
				throw new ApiError(404, 'board_not_found', Auth::lang('msg_module_is_not_exists'));
			}
			if ($expect_board && $module_info->module !== 'board')
			{
				throw new ApiError(400, 'not_board', 'not a board: ' . $module_info->module);
			}
		}

		$handler = new \ModuleHandler($module, $act, $mid, $document_srl, '');
		if (!$handler->init())
		{
			// 다른 게시판의 글 번호 등으로 코어가 리다이렉트하려 한 경우
			throw new ApiError(404, 'not_found', Auth::lang('msg_not_founded'));
		}
		$oModule = $handler->procModule();
		if (!$oModule)
		{
			throw new ApiError(404, 'not_found', Auth::lang('msg_module_is_not_exists'));
		}
		if (!$oModule->toBool())
		{
			// 스팸 방지 CAPTCHA 를 요구했거나 답이 틀렸다 (우회하지 않는다). 새 앱은 error.captcha 로 직접 풀고 다시 보낸다
			if (self::isCaptchaMessage($oModule->getMessage()))
			{
				throw self::captchaError($oModule->getMessage());
			}
			// 비회원이면 401: 앱이 로그인을 권한다
			throw new ApiError(self::isLoggedIn() ? 403 : 401, 'not_permitted', Auth::lang($oModule->getMessage()));
		}
		// 엔진의 알림 화면(message.html). 쪽지함(messages.html)과 헷갈리지 않게 이름이 정확히 같을 때만
		if (preg_match('/^message(\.html)?$/', basename((string)$oModule->getTemplateFile())))
		{
			$message = \Context::get('message') ?: (\Context::get('system_message') ?: 'msg_not_permitted');
			throw new ApiError(self::isLoggedIn() ? 403 : 401, 'not_permitted', strip_tags(Auth::lang($message)));
		}
		return $oModule;
	}

	/**
	 * 웹에서도 GET 으로 부르는 proc 동작 (주소 링크로 여는 다운로드). POST 로 바꾸면 비회원은 CSRF 검사에 걸린다.
	 * 엔진도 이 동작은 GET 을 받는다(module.xml method="GET|POST"). 쓰기가 아니라 CSRF 와 상관없다.
	 */
	private static $getProcs = array('procFileDownload');

	/** Rhymix 스팸 방지 CAPTCHA 가 거절한 메시지인가 (엔진이 언어 키 또는 번역된 글로 준다) */
	private static function isCaptchaMessage($message)
	{
		$message = (string)$message;
		if (strpos($message, 'msg_recaptcha_') === 0)
		{
			return true;
		}
		if (Core::$engine !== 'rhymix' || $message === '')
		{
			return false;
		}
		foreach (array('msg_recaptcha_invalid_response', 'msg_recaptcha_connection_error', 'msg_recaptcha_server_error') as $key)
		{
			$text = Auth::lang($key);
			if ($text !== $key && $text === $message)
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * 지금 회원이 이 동작(document·comment·signup·login)을 하려면 Rhymix 스팸 방지 CAPTCHA 를 풀어야 하는가.
	 * 앱에 미리 알린다(새 앱은 직접 풀고, 예전 앱은 웹으로 안내). 판단은 엔진(SpamfilterModel::isCaptchaEnabled)이 한다.
	 */
	public static function captchaRequired($action)
	{
		if (Core::$engine !== 'rhymix' || !class_exists('SpamfilterModel') || !method_exists('SpamfilterModel', 'isCaptchaEnabled'))
		{
			return false;
		}
		try
		{
			return (bool)\SpamfilterModel::isCaptchaEnabled($action);
		}
		catch (\Throwable $e)
		{
			return false;
		}
	}

	/**
	 * 앱이 직접 풀 CAPTCHA 정보: 사이트의 공개 열쇠(site_key, 웹 화면에도 나오는 값)와 모양.
	 * 앱은 이것으로 위젯을 띄워 받은 답을 captcha_response 로 보낸다. 비밀 열쇠는 주지 않는다.
	 * Rhymix 스팸 방지가 쓰는 reCAPTCHA·Turnstile 만. 그 밖의 종류나 XE 는 null (앱은 예전처럼 웹으로 안내한다).
	 */
	public static function captchaWidget()
	{
		if (Core::$engine !== 'rhymix')
		{
			return null;
		}
		try
		{
			$config = getModel('module')->getModuleConfig('spamfilter');
			$captcha = isset($config->captcha) ? $config->captcha : null;
			$type = $captcha ? strtolower((string)($captcha->type ?? '')) : '';
			if (!in_array($type, array('recaptcha', 'turnstile'), true) || empty($captcha->site_key) || empty($captcha->secret_key)
				|| !class_exists('Rhymix\\Modules\\Spamfilter\\Captcha\\' . $type))
			{
				return null;
			}
			$theme = (string)($captcha->theme ?? '');
			return array(
				'type' => $type,
				'site_key' => html_entity_decode((string)$captcha->site_key, ENT_QUOTES, 'UTF-8'),
				'theme' => in_array($theme, array('light', 'dark'), true) ? $theme : 'auto',
				'size' => ($captcha->size ?? '') === 'compact' ? 'compact' : 'normal',
			);
		}
		catch (\Throwable $e)
		{
			return null;
		}
	}

	/** 앱이 보낸 CAPTCHA 답 (Rhymix 만) */
	public static function captchaResponse()
	{
		if (Core::$engine !== 'rhymix')
		{
			return '';
		}
		$response = Core::param('captcha_response');
		return is_string($response) ? trim($response) : '';
	}

	/** 403 captcha_required. 새 앱이 풀 수 있게 error.captcha(위젯 정보, 없으면 null)를 더한다 */
	public static function captchaError($message = 'msg_recaptcha_invalid_response')
	{
		return new ApiError(403, 'captcha_required', Auth::lang($message), array('captcha' => self::captchaWidget()));
	}

	/**
	 * 엔진의 CAPTCHA 트리거(moduleObject.proc)를 거치지 않는 동작(앱 로그인)에서, 웹과 같은 판단과 확인을 한다.
	 * 이 동작에 CAPTCHA 를 요구하면(엔진 isCaptchaEnabled) 앱이 보낸 답을 엔진의 CAPTCHA 클래스(check)로 확인한다.
	 * 답이 없거나 틀리면 403 captcha_required. 엔진 트리거처럼 클래스가 없으면 확인하지 않는다.
	 */
	public static function checkCaptcha($action)
	{
		if (!self::captchaRequired($action))
		{
			return;
		}
		$config = getModel('module')->getModuleConfig('spamfilter');
		$class = 'Rhymix\\Modules\\Spamfilter\\Captcha\\' . $config->captcha->type;
		if (!class_exists($class))
		{
			return;
		}
		$response = self::captchaResponse();
		if ($response === '')
		{
			throw self::captchaError();
		}
		try
		{
			$class::init($config->captcha);
			$class::check($response);
		}
		catch (\Throwable $e)
		{
			throw self::captchaError($e->getMessage() ?: 'msg_recaptcha_invalid_response');
		}
	}

	/**
	 * 엔진의 CSRF 검사 통과 준비.
	 * CSRF 는 브라우저 쿠키를 노린 공격인데, 앱 요청은 쿠키가 아니라 Bearer 토큰으로 인증되므로 해당하지 않는다.
	 * 그래서 Bearer 로 인증된 요청에 한해 엔진이 요구하는 '같은 사이트에서 온 요청' 표시를 채운다.
	 */
	/** 비회원이 앱에서 하는 회원가입: 쿠키가 없는 앱 요청이라 CSRF 와 무관하므로 같은 준비를 한다 */
	public static $allowGuestWrite = false;

	private static function prepareWriteRequest()
	{
		if (!Auth::$token && !self::$allowGuestWrite)
		{
			return; // 비회원 쓰기는 엔진의 원래 검사를 그대로 받는다
		}
		$default_url = \Context::getDefaultUrl() ?: Core::$base_url;
		$_SERVER['HTTP_REFERER'] = $default_url;
		$_SERVER['HTTP_ORIGIN'] = rtrim(preg_replace('#^(https?://[^/]+).*$#', '$1', $default_url), '/');
		$_SERVER['HTTP_SEC_FETCH_SITE'] = 'same-origin';
		if (Core::$engine === 'rhymix' && \Rhymix\Framework\Config::get('security.check_csrf_token'))
		{
			$_SERVER['HTTP_X_CSRF_TOKEN'] = \Rhymix\Framework\Session::createToken();
		}
	}

	private static function isLoggedIn()
	{
		$info = \Context::get('logged_info');
		return $info && $info->member_srl;
	}

	private static function canRead($oModule, $oDocument)
	{
		if (!$oModule->grant->view && !$oDocument->isGranted())
		{
			return false;
		}
		// 상담 게시판: 관리 권한이 없으면 자기 글만
		if (!empty($oModule->consultation) && !$oDocument->isGranted())
		{
			$info = \Context::get('logged_info');
			return $info && (int)$oDocument->get('member_srl') === (int)$info->member_srl;
		}
		return true;
	}

	public static function boardInfo($oModule)
	{
		$info = $oModule->module_info;
		$grant = $oModule->grant;
		$categories = array();
		$category_list = (array)getModel('document')->getCategoryList($info->module_srl);
		// 분류를 꼭 골라야 하는 게시판 (Rhymix '분류 없음 허용' 끔이 기본, 관리자는 예외): 엔진의 글 등록 검사와 같은 판단
		$category_required = $category_list && Core::$engine === 'rhymix' && ($info->allow_no_category ?? 'N') !== 'Y' && empty($grant->manager);
		// 분류 사용 여부는 게시판 화면(board.view init)과 같이: hide_category → use_category → 분류가 있으면 사용
		$uses_category = isset($info->hide_category) ? $info->hide_category !== 'Y' : (isset($info->use_category) ? $info->use_category === 'Y' : true);
		if ($category_list && ($uses_category || $category_required))
		{
			foreach ($category_list as $category)
			{
				$categories[] = array(
					'category_srl' => (int)$category->category_srl,
					'parent_srl' => (int)$category->parent_srl,
					'title' => $category->title,
					'document_count' => (int)$category->document_count,
					// 지금 회원이 이 분류로 글을 쓸 수 있는지 (분류의 그룹 제한, 엔진이 계산한 값)
					'writable' => !isset($category->grant) || (bool)$category->grant,
				);
			}
		}
		$can_write = !empty($grant->write_document);
		$captcha = array(
			'document' => $can_write && self::captchaRequired('document'),
			'comment' => !empty($grant->write_comment) && self::captchaRequired('comment'),
		);
		return array(
			'mid' => $info->mid,
			'title' => $info->browser_title,
			'style' => self::listStyle($info),
			'columns' => self::columns((int)$info->module_srl),
			'use_secret' => strpos((string)($info->use_status ?? ''), 'SECRET') !== false || ($info->secret ?? '') === 'Y',
			'categories' => $categories,
			'grant' => array(
				'list' => (bool)$grant->list,
				'view' => (bool)$grant->view,
				'write_document' => (bool)$grant->write_document,
				'write_comment' => (bool)$grant->write_comment,
				'manager' => (bool)$grant->manager,
			),
			'upload' => self::uploadInfo($info, $grant),
			// 분류를 꼭 골라야 하는 게시판 (Rhymix '분류 없음 허용' 끔, 관리자는 예외): 엔진의 글 등록 검사와 같은 판단
			'category_required' => (bool)$category_required,
			// 글쓰기 화면에 그릴 추가 항목(확장 변수) 정의. 쓰기 권한이 있을 때만
			'extra_keys' => $can_write ? ExtraVars::keys((int)$info->module_srl) : array(),
			// 스팸 방지 CAPTCHA 를 요구하는 동작 (예전 앱은 true 면 웹에서 하도록 안내한다)
			'captcha' => $captcha,
			// 앱이 직접 풀 CAPTCHA 정보 (모듈 0.10.15~, 기능 captcha_solve). 요구하는 동작이 없거나 앱이 모르는 종류면 null
			'captcha_widget' => ($captcha['document'] || $captcha['comment']) ? self::captchaWidget() : null,
			// 웹의 글쓰기 화면 (앱에서 쓸 수 없는 게시판일 때 연다)
			'write_url' => getNotEncodedFullUrl('', 'mid', $info->mid, 'act', 'dispBoardWrite'),
		);
	}

	/**
	 * 글쓰기에 사진을 붙일 수 있는지와 크기 한도. 웹 에디터와 같은 규칙:
	 * 글쓰기 권한이 있고, 에디터 설정의 '파일 첨부 권한' 그룹에 들거나(비어 있으면 모두) 관리자.
	 * 앱은 JPEG 로 보내므로 허용 파일 형식에 jpg 가 들어 있어야 한다.
	 */
	public static function uploadInfo($module_info, $grant)
	{
		$logged_info = \Context::get('logged_info');
		$is_admin = $logged_info && $logged_info->is_admin === 'Y';
		$allowed = !empty($grant->write_document) && $logged_info && $logged_info->member_srl && self::canUploadFile((int)$module_info->module_srl, $logged_info);
		$config = Core::$engine === 'rhymix' ? \FileModel::getFileConfig((int)$module_info->module_srl) : getModel('file')->getFileConfig((int)$module_info->module_srl);
		$types = strtolower(trim((string)($config->allowed_filetypes ?? '')));
		if (!$is_admin && $types !== '' && strpos($types, '*.*') === false && !preg_match('/\\*\\.jpe?g\\b/', $types))
		{
			$allowed = false;
		}
		$mb = function ($value) use ($is_admin) {
			return (!$is_admin && (float)$value > 0) ? (int)round((float)$value * 1024 * 1024) : null;
		};
		return array(
			'allowed' => (bool)$allowed,
			// 바이트, null = 한도 없음(관리자 포함)
			'max_file_size' => $mb($config->allowed_filesize ?? 0),
			'max_total_size' => $mb($config->allowed_attach_size ?? 0),
		);
	}

	/** 에디터 설정의 파일 첨부 권한 (XE editor.model getModuleEditor, Rhymix 같은 규칙) */
	public static function canUploadFile($module_srl, $logged_info)
	{
		if ($logged_info && $logged_info->is_admin === 'Y')
		{
			return true;
		}
		$config = Core::$engine === 'rhymix' ? \EditorModel::getEditorConfig($module_srl) : getModel('editor')->getEditorConfig($module_srl);
		$groups = isset($config->upload_file_grant) ? $config->upload_file_grant : array();
		if (!is_array($groups))
		{
			$groups = $groups === '' || $groups === null ? array() : explode(',', (string)$groups);
		}
		$groups = array_filter($groups);
		if (!count($groups))
		{
			return true;
		}
		foreach (array_keys((array)($logged_info->group_list ?? array())) as $group_srl)
		{
			if (in_array($group_srl, $groups))
			{
				return true;
			}
		}
		return false;
	}

	/**
	 * 앱이 그릴 목록 모양: list | gallery | webzine | calendar. 게시판 스킨 설정을 따른다 (모듈에서 따로 정하지 않는다).
	 */
	private static function listStyle($info)
	{
		$skin = strtolower((string)$info->skin);
		if (strpos($skin, 'planner') !== false || strpos($skin, 'calendar') !== false)
		{
			return 'calendar';
		}
		$style = strtolower((string)($info->default_style ?? ($info->xv_list_t ?? '')));
		if (in_array($style, array('gallery', 'cloud_gall'), true) || strpos($skin, 'gallery') !== false)
		{
			return 'gallery';
		}
		if ($style === 'webzine')
		{
			return 'webzine';
		}
		return 'list';
	}

	/**
	 * 글을 보면 그 글에 걸린 내 알림(댓글·추천·이름 언급)을 읽음으로: 웹은 화면을 그리는 마지막 단계(moduleHandler.proc after)의
	 * 알림 모듈(ncenterlite) 트리거가 한다. 앱 API 는 화면을 그리지 않아 그 단계가 돌지 않으므로 알림 모듈의 트리거만 부른다
	 * (같은 단계의 다른 모듈 트리거는 회원 인증·가입 보완 화면으로 이동하는 것 등이 있어 부르지 않는다).
	 * XE 판은 _comment_srl 이 있으면 댓글 위치로 이동하고 끝내므로 비워 둔다. 읽음 처리 조건(설정 document_read)은 모듈이 정한다.
	 */
	private static function markNotificationsRead($oModule)
	{
		if (!self::isLoggedIn())
		{
			return;
		}
		$oController = getController('ncenterlite');
		if (!$oController || !method_exists($oController, 'triggerAfterModuleHandlerProc'))
		{
			return;
		}
		\Context::set('_comment_srl', null, true);
		try
		{
			$oController->triggerAfterModuleHandlerProc($oModule);
		}
		catch (\Throwable $e)
		{
			error_log('[appapi] ncenterlite read: ' . $e->getMessage());
		}
	}

	/**
	 * 앱이 이 게시판(mid)에서 연 글·댓글의 원래 게시판. 이 게시판의 것이거나, 이 게시판이 함께 보여 주는 게시판
	 * (Rhymix 통합 게시판 include_modules)의 것, 또는 전체 공지(is_notice A)면 그 원래 게시판 정보, 아니면 null.
	 * 원래 게시판도 지금 회원이 목록을 볼 수 있어야 한다 (쓰기·추천 등의 권한은 원래 게시판 기준으로 엔진이 다시 본다).
	 */
	public static function documentBoard($mid, $oItem)
	{
		$module_info = preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,59}$/', (string)$mid) ? getModel('module')->getModuleInfoByMid($mid) : null;
		if (!$module_info || $module_info->module !== 'board')
		{
			return null;
		}
		$srl = (int)$oItem->get('module_srl');
		if ($srl === (int)$module_info->module_srl)
		{
			return $module_info;
		}
		$included = in_array($srl, array_map('intval', explode(',', (string)($module_info->include_modules ?? ''))), true);
		if (!$included)
		{
			$document = $oItem->get('comment_srl') ? getModel('document')->getDocument((int)$oItem->get('document_srl'), false, false) : $oItem;
			$included = $document && $document->isExists() && $document->get('is_notice') === 'A';
		}
		$real = $included ? getModel('module')->getModuleInfoByModuleSrl($srl) : null;
		return ($real && $real->module === 'board' && self::canReadBoard($real)) ? $real : null;
	}

	/** 다른 화면(내 활동 등)에서 쓰는 글 요약: 게시판 목록과 같은 필드에 게시판 mid·이름을 더한다 */
	public static function summaryWithBoard($oDocument)
	{
		$item = self::documentSummary($oDocument);
		$board = self::boardOf((int)$oDocument->get('module_srl'));
		$item['mid'] = $board ? $board->mid : null;
		$item['board_title'] = $board ? $board->browser_title : null;
		return $item;
	}

	/** 글이 속한 게시판 (게시판이 아니거나 없으면 null) */
	public static function boardOf($module_srl)
	{
		static $cache = array();
		if (!array_key_exists($module_srl, $cache))
		{
			$module_info = $module_srl ? getModel('module')->getModuleInfoByModuleSrl($module_srl) : null;
			$cache[$module_srl] = ($module_info && $module_info->module === 'board') ? $module_info : null;
		}
		return $cache[$module_srl];
	}

	private static function canViewModule($module_srl)
	{
		static $cache = array();
		if (!isset($cache[$module_srl]))
		{
			$module_info = getModel('module')->getModuleInfoByModuleSrl($module_srl);
			$cache[$module_srl] = $module_info && self::grant($module_info)->view;
		}
		return $cache[$module_srl];
	}

	private static function documentSummary($oDocument)
	{
		$info = \Context::get('logged_info');
		$member_srl = (int)$oDocument->get('member_srl');
		// 열람 권한이 없는 게시판의 글은 제목까지만: 본문 요약·사진은 보내지 않는다
		$accessible = self::canViewModule((int)$oDocument->get('module_srl'))
			&& (!$oDocument->isSecret() || $oDocument->isGranted() || $oDocument->isAccessible());
		$columns = self::columns((int)$oDocument->get('module_srl'));
		return array(
			'document_srl' => (int)$oDocument->document_srl,
			'title' => html_entity_decode($oDocument->getTitleText(), ENT_QUOTES, 'UTF-8'),
			'author' => Core::displayName(html_entity_decode((string)$oDocument->getNickName(), ENT_QUOTES, 'UTF-8'), $member_srl, 'author_name'),
			'author_image' => self::profileImageUrl($oDocument),
			// 이름 메뉴(회원 정보·쪽지 등)용. 비회원 글·익명 글은 0
			'author_srl' => $member_srl > 0 ? $member_srl : 0,
			// 익명 게시판은 엔진이 회원 번호를 음수로 저장한다 (이름은 계속 감추고 본인에게만 내 글로)
				'is_mine' => $info && $info->member_srl && abs($member_srl) === (int)$info->member_srl,
			'regdate' => Core::isoTime($oDocument->get('regdate')),
			'last_update' => Core::isoTime($oDocument->get('last_update')),
			'category_srl' => (int)$oDocument->get('category_srl'),
			'comment_count' => (int)$oDocument->getCommentCount(),
			// 게시판 목록 설정에서 숨긴 값은 보내지 않는다 (null)
			'read_count' => $columns['read_count'] ? (int)$oDocument->get('readed_count') : null,
			'vote_count' => $columns['vote_count'] ? (int)$oDocument->get('voted_count') : null,
			'is_notice' => $oDocument->isNotice() ? true : false,
			'is_secret' => $oDocument->isSecret() ? true : false,
			'has_files' => $oDocument->hasUploadedFiles() ? true : false,
			'thumbnail' => $accessible ? self::thumbnailUrl($oDocument) : null,
			'summary' => $accessible ? html_entity_decode(trim((string)$oDocument->getSummary(120)), ENT_QUOTES, 'UTF-8') : '',
		);
	}

	/**
	 * 게시판 관리자가 목록에 보이게 설정한 항목 (조회수·추천수를 숨긴 게시판이 있다).
	 */
	private static function columns($module_srl)
	{
		static $cache = array();
		if (!isset($cache[$module_srl]))
		{
			$list_config = (array)getModel('board')->getListConfig($module_srl);
			$cache[$module_srl] = array(
				'read_count' => isset($list_config['readed_count']),
				'vote_count' => isset($list_config['voted_count']),
			);
		}
		return $cache[$module_srl];
	}

	/**
	 * 목록용 썸네일 주소. 목록 응답에서 썸네일을 만들지 않는다 (처음 만들 때 글마다 오래 걸린다).
	 * - 이미 만든 썸네일이 있으면 그 주소
	 * - 이미지 없는 글로 판정된 적이 있으면 null
	 * - 아직이면 앱이 이미지를 그릴 때 만드는 주소(r=thumb, 서버 서명 포함)
	 */
	private static function thumbnailUrl($oDocument)
	{
		$srl = (int)$oDocument->document_srl;
		$base = 'files/thumbnails/' . getNumberingPath($srl, 3) . '400x400.crop';
		if (file_exists($base . '.jpg'))
		{
			clearstatcache(true, $base . '.jpg');
			$size = filesize($base . '.jpg');
			return $size > 0 ? Core::absoluteUrl($base . '.jpg') . '?t=' . filemtime($base . '.jpg') : null;
		}
		if (file_exists($base . '.lock'))
		{
			return null;
		}
		$has_image = $oDocument->get('uploaded_count') > 0 || stripos((string)$oDocument->get('content'), '<img') !== false;
		if (!$has_image)
		{
			return null;
		}
		return Core::$api_url . '?r=thumb&srl=' . $srl . '&s=' . self::thumbSignature($srl);
	}

	private static function thumbSignature($srl)
	{
		return substr(hash_hmac('sha256', 'thumb|' . (int)$srl, Core::secret()), 0, 20);
	}

	/**
	 * 썸네일을 필요할 때 만든다 (앱의 이미지 요청). 서명은 목록을 볼 수 있었던 회원에게만 발급된다.
	 */
	public static function thumb()
	{
		$srl = Core::intParam('srl');
		$signature = (string)Core::param('s', '');
		if (!$srl || !hash_equals(self::thumbSignature($srl), $signature))
		{
			throw new ApiError(404, 'not_found', 'not found');
		}
		$oDocument = getModel('document')->getDocument($srl, false, false);
		$url = ($oDocument && $oDocument->isExists()) ? $oDocument->getThumbnail(400, 400, 'crop') : null;
		if (!$url)
		{
			throw new ApiError(404, 'no_thumbnail', 'no thumbnail');
		}
		while (ob_get_level() > 0)
		{
			ob_end_clean();
		}
		Core::endRequestSession();
		Response::$passthrough = true;
		header('Cache-Control: public, max-age=86400');
		header('Location: ' . Core::absoluteUrl($url), true, 302);
		exit;
	}

	private static function profileImageUrl($oItem)
	{
		$src = $oItem->getProfileImage();
		return $src ? Core::absoluteUrl($src) : null;
	}

	private static function extraVars($oDocument)
	{
		$result = array();
		foreach ((array)$oDocument->getExtraVars() as $extra)
		{
			$value = method_exists($extra, 'getValueHTML') ? $extra->getValueHTML() : $extra->value;
			if ($value === null || $value === '' || $value === array())
			{
				continue;
			}
			$result[] = array(
				'name' => $extra->name,
				'type' => $extra->type,
				'value_html' => Core::absolutizeHtml(is_array($value) ? implode(', ', $value) : (string)$value),
			);
		}
		return $result;
	}

	private static function files($files, $mid)
	{
		$result = array();
		foreach ((array)$files as $file)
		{
			if ($file->isvalid !== 'Y')
			{
				continue;
			}
			$is_image = (bool)preg_match('/\.(jpe?g|png|gif|webp|bmp|heic)$/i', $file->source_filename);
			$result[] = array(
				'file_srl' => (int)$file->file_srl,
				'name' => $file->source_filename,
				'size' => (int)$file->file_size,
				'is_image' => $is_image,
				'image_url' => ($is_image && $file->direct_download === 'Y') ? Core::absoluteUrl($file->uploaded_filename) : null,
				'download' => array('r' => 'file', 'file_srl' => (int)$file->file_srl, 'sid' => $file->sid, 'mid' => $mid),
			);
		}
		return $result;
	}

	private static function commentPage($oDocument, $mid)
	{
		$comments = array();
		$info = \Context::get('logged_info');
		foreach ((array)$oDocument->getComments() as $oComment)
		{
			$accessible = !$oComment->isSecret() || $oComment->isAccessible() || $oComment->isGranted();
			$member_srl = (int)$oComment->get('member_srl');
			$comments[] = array(
				'comment_srl' => (int)$oComment->comment_srl,
				'parent_srl' => (int)$oComment->get('parent_srl'),
				'depth' => (int)$oComment->get('depth'),
				'author' => Core::displayName(html_entity_decode((string)$oComment->getNickName(), ENT_QUOTES, 'UTF-8'), $member_srl, 'author_name'),
				'author_image' => self::profileImageUrl($oComment),
				'author_srl' => $member_srl > 0 ? $member_srl : 0,
				// 익명 게시판은 엔진이 회원 번호를 음수로 저장한다 (이름은 계속 감추고 본인에게만 내 글로)
				'is_mine' => $info && $info->member_srl && abs($member_srl) === (int)$info->member_srl,
				'regdate' => Core::isoTime($oComment->get('regdate')),
				'is_secret' => $oComment->isSecret() ? true : false,
				'content_html' => $accessible ? Core::absolutizeHtml($oComment->getContent(false, false, false)) : null,
				'vote_count' => (int)$oComment->get('voted_count'),
				'can_delete' => (bool)$oComment->isGranted(),
				'files' => ($accessible && $oComment->hasUploadedFiles()) ? self::files($oComment->getUploadedFiles(), $mid) : array(),
			);
		}
		$nav = $oDocument->comment_page_navigation;
		return array(
			'items' => $comments,
			'page' => (int)($nav ? $nav->cur_page : 1),
			'total_pages' => (int)($nav ? $nav->total_page : 1),
			'total_count' => (int)$oDocument->getCommentCount(),
		);
	}
}
