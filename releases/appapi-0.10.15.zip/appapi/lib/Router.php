<?php
namespace AppApi;

class Router
{
	/**
	 * route => [허용 메서드, 로그인 필수 여부, 처리 함수]
	 * 로그인이 필수가 아닌 route 도 토큰이 오면 그 회원 권한으로 처리한다.
	 */
	private static $routes = array(
		'site' => array('GET', false, array('AppApi\Menu', 'site')),
		'menu' => array('GET', false, array('AppApi\Menu', 'menus')),
		'auth.login' => array('POST', null, array('AppApi\Auth', 'login')),
		'auth.refresh' => array('POST', null, array('AppApi\Auth', 'refresh')),
		'auth.logout' => array('POST', null, array('AppApi\Auth', 'logout')),
		'me' => array('GET', true, array('AppApi\Auth', 'me')),
		'me.form' => array('GET', true, array('AppApi\Member', 'form')),
		'me.update' => array('POST', true, array('AppApi\Member', 'update')),
		'me.password' => array('POST', true, array('AppApi\Member', 'password')),
		'me.image' => array('POST', true, array('AppApi\Member', 'image')),
		'me.leave' => array('POST', true, array('AppApi\Member', 'leave')),
		'signup.form' => array('GET', false, array('AppApi\Member', 'signupForm')),
		'signup' => array('POST', null, array('AppApi\Member', 'signup')),
		'feed' => array('GET', false, array('AppApi\Board', 'feed')),
		'board' => array('GET', false, array('AppApi\Board', 'documents')),
		'document' => array('GET', false, array('AppApi\Board', 'document')),
		'comments' => array('GET', false, array('AppApi\Board', 'comments')),
		'page' => array('GET', false, array('AppApi\Board', 'page')),
		'resolve' => array('GET', false, array('AppApi\Board', 'resolve')),
		'file' => array('GET', false, array('AppApi\Board', 'file')),
		'thumb' => array('GET', null, array('AppApi\Board', 'thumb')),
		'document.write' => array('POST', true, array('AppApi\Write', 'insertDocument')),
		'document.delete' => array('POST', true, array('AppApi\Write', 'deleteDocument')),
		'document.source' => array('GET', true, array('AppApi\Write', 'documentSource')),
		'document.update' => array('POST', true, array('AppApi\Write', 'updateDocument')),
		'document.tempsave' => array('POST', true, array('AppApi\Write', 'tempSave')),
		'comment.write' => array('POST', true, array('AppApi\Write', 'insertComment')),
		'comment.delete' => array('POST', true, array('AppApi\Write', 'deleteComment')),
		'document.vote' => array('POST', true, array('AppApi\Actions', 'vote')),
		'document.voters' => array('GET', false, array('AppApi\Actions', 'voters')),
		'document.scrap' => array('POST', true, array('AppApi\Actions', 'scrap')),
		'document.declare' => array('POST', true, array('AppApi\Actions', 'report')),
		// 비회원도 투표할 수 있다(웹과 같이 엔진이 IP 로 한 번만 받는다)
		'poll.vote' => array('POST', false, array('AppApi\Polls', 'vote')),
		'member.menu' => array('GET', false, array('AppApi\People', 'menu')),
		'member.info' => array('GET', true, array('AppApi\People', 'info')),
		'message.send' => array('POST', true, array('AppApi\People', 'sendMessage')),
		'friend.add' => array('POST', true, array('AppApi\People', 'addFriend')),
		'notify.count' => array('GET', true, array('AppApi\Notify', 'count')),
		'notify.list' => array('GET', true, array('AppApi\Notify', 'lists')),
		'notify.read' => array('POST', true, array('AppApi\Notify', 'read')),
		'notify.readall' => array('POST', true, array('AppApi\Notify', 'readAll')),
		'my.menu' => array('GET', true, array('AppApi\My', 'menu')),
		'my.documents' => array('GET', true, array('AppApi\My', 'documents')),
		'my.comments' => array('GET', true, array('AppApi\My', 'comments')),
		'my.scraps' => array('GET', true, array('AppApi\My', 'scraps')),
		'my.scrap.delete' => array('POST', true, array('AppApi\My', 'deleteScrap')),
		'my.logins' => array('GET', true, array('AppApi\My', 'logins')),
		'my.saved' => array('GET', true, array('AppApi\My', 'saved')),
		'my.saved.delete' => array('POST', true, array('AppApi\My', 'deleteSaved')),
		'my.messages' => array('GET', true, array('AppApi\My', 'messages')),
		'my.message' => array('GET', true, array('AppApi\My', 'message')),
		'my.message.delete' => array('POST', true, array('AppApi\My', 'deleteMessage')),
		'my.message.store' => array('POST', true, array('AppApi\My', 'storeMessage')),
		'my.friends' => array('GET', true, array('AppApi\My', 'friends')),
		'my.friend.delete' => array('POST', true, array('AppApi\My', 'deleteFriend')),
	);

	public static function run()
	{
		// 애드온·엔진이 화면을 찍고 exit 하면 JSON 오류로 바꾼다 (Response::onShutdown)
		register_shutdown_function(array('AppApi\Response', 'onShutdown'));
		try
		{
			$route = isset($_GET['r']) ? (string)$_GET['r'] : '';
			if (!isset(self::$routes[$route]))
			{
				throw new ApiError(404, 'unknown_route', 'unknown route');
			}
			list($method, $auth, $handler) = self::$routes[$route];
			if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') !== $method)
			{
				throw new ApiError(405, 'method_not_allowed', 'use ' . $method);
			}

			Core::boot();
			if ($auth !== null)
			{
				Auth::authenticate($auth);
			}
			Response::ok(call_user_func($handler));
		}
		catch (ApiError $e)
		{
			Response::error($e->status, $e->error_code, $e->getMessage(), (array)$e->extra);
		}
		catch (\Throwable $e)
		{
			error_log('[appapi] ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
			Response::error(500, 'server_error', 'server error');
		}
	}
}
