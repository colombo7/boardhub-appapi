<?php
namespace AppApi;

/**
 * 사이트 코어(구 XE 1.x 또는 Rhymix) 부트스트랩과 엔진별 차이 흡수.
 *
 * 원칙: 코어 파일은 고치지 않고, 권한 판단은 코어 코드에 맡긴다.
 */
class Core
{
	/** @var string 'xe' | 'rhymix' */
	public static $engine;

	/** @var array 앱이 보낸 요청 값 (쿼리 + JSON 본문) */
	public static $params = array();

	/** @var string 원래 HTTP 메서드 */
	public static $method = 'GET';

	/** @var string 사이트 기본 주소 (예: https://www.kgpa.org/) */
	public static $base_url;

	/** @var string 이 API 의 주소 (예: https://www.kgpa.org/modules/appapi/api.php) */
	public static $api_url;

	public static function boot()
	{
		self::$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
		self::$params = self::readParams();

		// 코어는 우리가 명시적으로 넣는 값만 보게 한다 (비밀번호 등이 Context 로 새지 않도록).
		$_GET = $_POST = $_REQUEST = array();
		// 앱은 쿠키를 쓰지 않는다. 브라우저(관리 화면의 연결 확인 등)가 보낸 로그인 쿠키를 코어가 보지 않게 버린다:
		// 그 세션으로 요청을 처리한 뒤 endRequestSession() 이 지우면, 웹에 로그인한 사람(관리자)이 로그아웃된다.
		$_COOKIE = array();
		unset($_SERVER['HTTP_COOKIE']);
		unset($_SERVER['CONTENT_TYPE'], $_SERVER['HTTP_CONTENT_TYPE']);
		$GLOBALS['HTTP_RAW_POST_DATA'] = '';
		$_SERVER['REQUEST_METHOD'] = 'GET';

		// 코어는 SCRIPT_NAME 으로 사이트 주소를 계산한다. 사이트 index.php 인 것처럼 맞춘다.
		// 모듈(modules/appapi/api.php)로 설치돼도, 루트의 appapi/index.php 로 불려도 사이트 루트를 찾는다.
		$site_dir = self::siteDir();
		$script_file = str_replace('\\', '/', realpath($_SERVER['SCRIPT_FILENAME']) ?: $_SERVER['SCRIPT_FILENAME']);
		$relative = substr($script_file, strlen(str_replace('\\', '/', $site_dir)));
		$script_name = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
		$original_script_name = $script_name;
		$base_path = rtrim(substr($script_name, 0, max(0, strlen($script_name) - strlen($relative))), '/');
		$_SERVER['SCRIPT_NAME'] = $_SERVER['PHP_SELF'] = $base_path . '/index.php';
		$_SERVER['SCRIPT_FILENAME'] = $site_dir . '/index.php';
		$_SERVER['REQUEST_URI'] = $base_path . '/';
		chdir($site_dir);

		if (!defined('__XE__'))
		{
			define('__XE__', true);
		}
		ob_start();
		require $site_dir . '/config/config.inc.php';
		self::$engine = defined('RX_VERSION') ? 'rhymix' : 'xe';

		$oContext = \Context::getInstance();
		$oContext->init();
		if (!\Context::isInstalled())
		{
			throw new ApiError(503, 'not_installed', 'site is not installed');
		}
		\Mobile::setMobile(false);
		\Context::loadLang('./modules/member/lang');

		$scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
		self::$base_url = $scheme . '://' . $_SERVER['HTTP_HOST'] . $base_path . '/';
		self::$api_url = $scheme . '://' . $_SERVER['HTTP_HOST'] . $original_script_name;
	}

	/**
	 * config/config.inc.php 가 있는 곳(사이트 루트)까지 위로 올라가며 찾는다.
	 */
	private static function siteDir()
	{
		$dir = realpath(APPAPI_DIR);
		for ($i = 0; $i < 4 && $dir; $i++)
		{
			$dir = dirname($dir);
			if (file_exists($dir . '/config/config.inc.php'))
			{
				return $dir;
			}
		}
		throw new ApiError(500, 'site_not_found', 'site root not found');
	}

	private static function readParams()
	{
		$params = $_GET;
		$content_type = $_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? '');
		if (stripos($content_type, 'json') !== false)
		{
			$json = json_decode(file_get_contents('php://input'), true);
			if (is_array($json))
			{
				$params = array_merge($params, $json);
			}
		}
		elseif ($_POST)
		{
			$params = array_merge($params, $_POST);
		}
		return $params;
	}

	public static function param($key, $default = null)
	{
		return isset(self::$params[$key]) ? self::$params[$key] : $default;
	}

	public static function intParam($key, $default = 0)
	{
		$value = self::param($key);
		return ($value !== null && ctype_digit((string)$value)) ? (int)$value : $default;
	}

	/**
	 * 이번 요청 동안만 해당 회원으로 로그인한 상태를 만든다.
	 * 웹 세션과 같은 경로(setSessionInfo)를 타므로 그룹·권한 계산이 웹과 같다.
	 */
	public static function loginAs($member_srl)
	{
		if (self::$engine === 'rhymix')
		{
			\Rhymix\Framework\Session::login($member_srl, false);
		}
		else
		{
			$_SESSION['member_srl'] = $member_srl;
			$_SESSION['is_logged'] = true;
			$_SESSION['ipaddress'] = $_SERVER['REMOTE_ADDR'];
		}
		getController('member')->setSessionInfo();

		$logged_info = \Context::get('logged_info');
		return $logged_info && (int)$logged_info->member_srl === (int)$member_srl;
	}

	/**
	 * 앱은 쿠키 세션을 쓰지 않는다. 요청마다 생긴 PHP 세션은 응답 전에 폐기한다.
	 */
	public static function endRequestSession()
	{
		if (session_status() === PHP_SESSION_ACTIVE)
		{
			$_SESSION = array();
			@session_destroy();
		}
		if (!headers_sent() && function_exists('header_remove'))
		{
			header_remove('Set-Cookie');
		}
	}

	/**
	 * 앱 전용 테이블에 쓸 PDO 연결. 두 엔진의 DB 클래스 API 가 달라 직접 연결한다.
	 */
	public static function pdo()
	{
		static $pdo = null;
		if ($pdo)
		{
			return $pdo;
		}

		if (self::$engine === 'rhymix')
		{
			$c = \Rhymix\Framework\Config::get('db.master');
			$host = $c['host'];
			$port = $c['port'];
			$user = $c['user'];
			$pass = $c['pass'];
			$name = $c['database'];
			$socket = $c['socket'] ?? '';
		}
		else
		{
			$c = \Context::getDBInfo()->master_db;
			$host = $c['db_hostname'];
			$port = $c['db_port'];
			$user = $c['db_userid'];
			$pass = $c['db_password'];
			$name = $c['db_database'];
			$socket = '';
		}

		$dsn = $socket ? "mysql:unix_socket=$socket;dbname=$name" : "mysql:host=$host;port=" . ($port ?: 3306) . ";dbname=$name";
		$pdo = new \PDO($dsn . ';charset=utf8', $user, $pass, array(
			\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
			\PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
			\PDO::ATTR_EMULATE_PREPARES => false,
		));
		return $pdo;
	}

	/**
	 * 서버만 아는 서명 키 (썸네일 주소 서명 등). DB 접속 정보에서 만들어 따로 저장하지 않는다.
	 */
	public static function secret()
	{
		static $secret = null;
		if ($secret === null)
		{
			if (self::$engine === 'rhymix')
			{
				$c = \Rhymix\Framework\Config::get('db.master');
				$seed = $c['pass'] . '|' . $c['database'] . '|' . $c['prefix'];
			}
			else
			{
				$c = \Context::getDBInfo()->master_db;
				$seed = $c['db_password'] . '|' . $c['db_database'] . '|' . $c['db_table_prefix'];
			}
			$secret = hash('sha256', 'appapi|' . $seed);
		}
		return $secret;
	}

	public static function tablePrefix()
	{
		if (self::$engine === 'rhymix')
		{
			return \Rhymix\Framework\Config::get('db.master.prefix');
		}
		return \Context::getDBInfo()->master_db['db_table_prefix'];
	}

	/**
	 * 사이트별 설정 (appapi/config.php, 없으면 기본값).
	 */
	public static function config($key = null)
	{
		static $config = null;
		if ($config === null)
		{
			$config = array(
				'access_ttl' => 3600,
				'refresh_ttl' => 86400 * 365,
				'site_name' => '',
				'theme_color' => '',
				'logo_url' => '',
				'icon_url' => '',
				// 추천인 목록의 이름: nick_name_user_name = 닉네임(이름), nick_name = 닉네임만
				'voter_name' => 'nick_name_user_name',
				// 글·댓글 작성자 이름: 기본은 닉네임만 (웹과 같게)
				'author_name' => 'nick_name',
			);
			if (file_exists(APPAPI_DIR . '/config.php'))
			{
				$custom = include APPAPI_DIR . '/config.php';
				if (is_array($custom))
				{
					$config = array_merge($config, $custom);
				}
			}
			// 관리자 화면(앱 연동 설정)에서 저장한 값이 가장 우선
			$saved = getModel('module')->getModuleConfig('appapi');
			if (is_object($saved))
			{
				foreach (array('site_name', 'theme_color', 'logo_url', 'icon_url', 'voter_name', 'author_name') as $name)
				{
					if (isset($saved->$name) && trim((string)$saved->$name) !== '')
					{
						$config[$name] = trim((string)$saved->$name);
					}
				}
			}
		}
		return $key === null ? $config : ($config[$key] ?? null);
	}

	/**
	 * 앱에 보낼 회원 이름. 설정이 nick_name_user_name 이면 닉네임(이름), 닉네임과 이름이 같거나 이름이 없으면 닉네임만.
	 * @param string $setting 설정 이름 (author_name, voter_name)
	 */
	public static function displayName($nick_name, $member_srl, $setting)
	{
		$nick_name = (string)$nick_name;
		if (self::config($setting) !== 'nick_name_user_name' || (int)$member_srl <= 0)
		{
			return $nick_name;
		}
		$user_name = self::userName((int)$member_srl);
		return ($user_name === '' || $user_name === $nick_name) ? $nick_name : $nick_name . '(' . $user_name . ')';
	}

	/** 회원 실명 (요청 안에서는 한 번만 읽는다) */
	public static function userName($member_srl)
	{
		static $cache = array();
		if (!isset($cache[$member_srl]))
		{
			$stmt = self::pdo()->prepare('SELECT user_name FROM `' . self::tablePrefix() . 'member` WHERE member_srl = ?');
			$stmt->execute(array($member_srl));
			$cache[$member_srl] = trim((string)$stmt->fetchColumn());
		}
		return $cache[$member_srl];
	}

	/**
	 * 상대 주소(./files/..., /files/..., files/...)를 사이트 절대 주소로 바꾼다.
	 */
	public static function absoluteUrl($url)
	{
		$url = trim((string)$url);
		if ($url === '' || preg_match('#^(data:|mailto:|tel:|//)#i', $url))
		{
			return $url;
		}
		if (preg_match('#^https?:#i', $url))
		{
			return preg_replace('#(?<=[^:/])/(\./)+#', '/', $url);
		}
		if ($url[0] === '/')
		{
			$p = parse_url(self::$base_url);
			return $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . $url;
		}
		return self::$base_url . preg_replace('#^\./#', '', $url);
	}

	public static function absolutizeHtml($html)
	{
		return preg_replace_callback('/\b(src|href|poster)\s*=\s*(["\'])(.*?)\2/i', function ($m) {
			return $m[1] . '=' . $m[2] . Core::absoluteUrl(html_entity_decode($m[3], ENT_QUOTES)) . $m[2];
		}, $html);
	}

	public static function isoTime($ymdhis)
	{
		if (!$ymdhis)
		{
			return null;
		}
		$t = ztime($ymdhis);
		return $t ? date('c', $t) : null;
	}
}
