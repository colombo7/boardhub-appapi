<?php
namespace AppApi;

/**
 * API 오류. Router 가 잡아서 JSON 오류 응답으로 바꾼다.
 */
class ApiError extends \Exception
{
	public $status;
	public $error_code;
	/** @var array error 에 더할 값 (예: captcha_required 의 captcha 위젯 정보). code·message 는 덮지 않는다 */
	public $extra;

	public function __construct($status, $error_code, $message = '', array $extra = array())
	{
		parent::__construct($message ?: $error_code);
		$this->status = $status;
		$this->error_code = $error_code;
		$this->extra = $extra;
	}
}

class Response
{
	/** 응답을 이미 보냈다 */
	public static $sent = false;

	/** 엔진이 직접 내보내고 끝내는 요청(첨부 내려받기·썸네일 주소 넘기기): 끝날 때 JSON 으로 바꾸지 않는다 */
	public static $passthrough = false;

	/**
	 * 성공 응답을 보내고 끝낸다.
	 */
	public static function ok($data, $status = 200)
	{
		self::send($status, array('ok' => true, 'data' => $data));
	}

	public static function error($status, $error_code, $message, array $extra = array())
	{
		self::send($status, array('ok' => false, 'error' => array('code' => $error_code, 'message' => $message) + $extra));
	}

	/**
	 * PHP 가 끝날 때(Router 가 등록): 응답을 보내기 전에 끝났으면 애드온·엔진이 화면(HTML)을 찍고 exit 한 것이다
	 * (예: 특정 동작을 막는 애드온, 알림창 페이지). 앱이 읽을 수 있게 그 글자만 뽑아 JSON 오류(blocked)로 바꾼다.
	 * 이미 브라우저로 나간 출력은 되돌릴 수 없으니 그때는 둔다.
	 */
	public static function onShutdown()
	{
		if (self::$sent || self::$passthrough || headers_sent())
		{
			return;
		}
		$chunks = array();
		while (ob_get_level() > 0)
		{
			$chunks[] = (string)ob_get_clean();
		}
		$output = implode('', array_reverse($chunks));
		$error = error_get_last();
		if ($error && in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR), true))
		{
			error_log('[appapi] fatal: ' . $error['message'] . ' @ ' . $error['file'] . ':' . $error['line']);
			self::send(500, array('ok' => false, 'error' => array('code' => 'server_error', 'message' => 'server error')), false);
			return;
		}
		$message = self::textOf($output);
		if ($message === '')
		{
			$message = class_exists('appapiText') ? \appapiText::t('사이트가 이 요청을 처리하지 않았습니다. 웹에서 해 주세요.') : 'blocked';
		}
		self::send(403, array('ok' => false, 'error' => array('code' => 'blocked', 'message' => $message)), false);
	}

	/** 엔진·애드온이 찍은 HTML 에서 사람이 읽을 글자 (알림창 alert("…") 이 있으면 그 글) */
	private static function textOf($html)
	{
		$html = (string)$html;
		if (preg_match('/alert\(\s*([\'"])((?:\\\\.|(?!\1).)*)\1\s*\)/s', $html, $m))
		{
			$text = stripcslashes($m[2]);
		}
		else
		{
			if (preg_match('#<body[^>]*>(.*)</body>#is', $html, $body))
			{
				$html = $body[1];
			}
			$html = preg_replace('#<(script|style|noscript|head)\b[^>]*>.*?</\1>#is', ' ', $html);
			$text = html_entity_decode(strip_tags(preg_replace('#<br\s*/?>|</p>|</div>|</h\d>#i', "\n", $html)), ENT_QUOTES, 'UTF-8');
		}
		$text = trim(preg_replace('/[ \t\r\n]+/u', ' ', $text));
		return mb_substr($text, 0, 300);
	}

	private static function send($status, $body, $exit = true)
	{
		self::$sent = true;
		// 코어나 애드온이 흘린 출력은 버린다.
		while (ob_get_level() > 0)
		{
			ob_end_clean();
		}
		Core::endRequestSession();
		if (!headers_sent())
		{
			// 코어가 리다이렉트하려고 남긴 헤더는 지운다.
			header_remove('Location');
			http_response_code($status);
			header('Content-Type: application/json; charset=utf-8');
			header('Cache-Control: no-store');
			header('X-Content-Type-Options: nosniff');
		}
		echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		// 끝날 때 불렸으면 exit 하지 않는다 (엔진이 등록한 다른 마무리 함수가 돌게)
		if ($exit)
		{
			exit;
		}
	}
}
