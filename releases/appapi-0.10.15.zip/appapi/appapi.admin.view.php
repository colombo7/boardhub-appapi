<?php
/**
 * 앱 연동 설정 화면
 */
class appapiAdminView extends appapi
{
	function init()
	{
		$this->setTemplatePath($this->module_path . 'tpl');
	}

	function dispAppapiAdminConfig()
	{
		$config = getModel('module')->getModuleConfig('appapi');
		if (!is_object($config))
		{
			$config = new stdClass;
		}
		$view = new stdClass;
		foreach (array('site_name', 'theme_color', 'logo_url', 'icon_url', 'voter_name', 'author_name', 'share_site') as $key)
		{
			$view->$key = htmlspecialchars(isset($config->$key) ? (string)$config->$key : '', ENT_QUOTES, 'UTF-8');
		}
		Context::set('appapi_config', $view);
		Context::set('appapi_url', htmlspecialchars(Context::getDefaultUrl() . 'modules/appapi/api.php?r=site', ENT_QUOTES, 'UTF-8'));
		// 관리 화면이 스스로 접속해 보는 주소 (지금 연 주소와 같은 곳이어야 브라우저가 막지 않는다)
		Context::set('appapi_check_url', htmlspecialchars(Context::getRequestUri() . 'modules/appapi/api.php?r=site', ENT_QUOTES, 'UTF-8'));
		Context::set('appapi_engine', defined('RX_VERSION') ? 'Rhymix ' . RX_VERSION : 'XE ' . __XE_VERSION__);

		// 모듈 업데이트: [업데이트 확인]을 눌렀을 때만 밖(github)에 묻는다
		require_once __DIR__ . '/appapi.updater.php';
		Context::set('appapi_version', appapiUpdater::currentVersion());
		$update = Context::get('check_update') ? appapiUpdater::check() : null;
		if ($update)
		{
			foreach (array('notes', 'error', 'latest', 'date') as $key)
			{
				$update[$key] = htmlspecialchars((string)$update[$key], ENT_QUOTES, 'UTF-8');
			}
			$update['problems'] = array_map(function ($path) { return htmlspecialchars($path, ENT_QUOTES, 'UTF-8'); }, $update['problems']);
		}
		Context::set('appapi_update', $update ? (object)$update : null);
		// 값이 든 문구는 여기서 만든다 (템플릿 {…} 안에는 {0} 을 못 쓴다)
		$latest = $update ? $update['latest'] : '';
		Context::set('appapi_text', array(
			'is_newer' => appapiText::t('배포된 최신 버전({0})보다 새 버전입니다. 업데이트할 것이 없습니다.', $latest),
			'update_to' => appapiText::t('{0} 로 업데이트', $latest),
			'confirm' => htmlspecialchars(json_encode(appapiText::t('{0} 로 업데이트할까요? 지금 파일은 files/appapi_backup 에 백업됩니다.', $latest), JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'),
		));
		Context::set('tr', new appapiTextView());
		// 연결 확인 스크립트 문구
		$js = array();
		foreach (array('✓ 정상', '✗ 접속 안 됨', '직접 열어 보기', '앱에서 이 사이트를 추가할 수 있습니다', '모듈', '응답 오류', '응답이 앱 형식이 아닙니다', '서버에 접속하지 못했습니다', '응답이 너무 늦습니다') as $ko)
		{
			$js[$ko] = appapiText::t($ko);
		}
		Context::set('appapi_js_text', htmlspecialchars(json_encode($js, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8'));
		$result = isset($_SESSION['appapi_update_result']) ? $_SESSION['appapi_update_result'] : null;
		unset($_SESSION['appapi_update_result']);
		if ($result)
		{
			$result['message'] = htmlspecialchars((string)$result['message'], ENT_QUOTES, 'UTF-8');
			$result['backup'] = htmlspecialchars((string)$result['backup'], ENT_QUOTES, 'UTF-8');
		}
		Context::set('appapi_update_result', $result ? (object)$result : null);
		$this->setTemplateFile('config');
	}
}
